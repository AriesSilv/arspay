<?php
class Config{
    public $BASE_URL = "http://localhost:8080/arspay/public/?url=";
    public $DB_HOST = "localhost:3306";
    public $DB_USER = "root";
    public $DB_PASS = "root";
    public $DB_NAME = "arspay";
    public $midtrans = [];
    public function __construct(){
    $this->midtrans["url"] = "https://harmonical-glows.000webhostapp.com/payment/";
    $this->midtrans["key"] = base64_encode("alfin123");
    $this->midtrans["clientkey"] = "SB-Mid-client-jWU17qpRQ3y7s9hM";
    $this->midtrans["fee"] = 1000;
    }
    
    
}