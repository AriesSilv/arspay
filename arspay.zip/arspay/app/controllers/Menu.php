<?php
class Menu extends Controller{
    public function __construct(){
        parent::__construct();
        $this->is_loggin();
        $this->is_menu();
    }
    public function Index(){
        $data["title"] = "Menu Management";
        $data["user"] = $this->userdata;
        
        $data["menu"] = $this->model("Menu_model")->getmenu();
        $this->view("templates/header",$data);
        $this->view("menu/index",$data);
        $this->view("templates/footer",$data);
        
        
        if (isset($_POST["add"])) {
            $this->model("Menu_model")->insertmenu($_POST);
        }elseif (isset($_POST["edit"])) {
            $this->model("Menu_model")->updatemenu($_POST);
        }elseif (isset($_POST["delete"])) {
            $this->model("Menu_model")->deletemenu($_POST);
        }
    }
    public function ManageSubmenu(){
        $data["title"] = "Submenu Management";
        $data["user"] = $this->userdata;
        
        $data["submenu"] = $this->model("Menu_model")->getsubmenu();
        
        $this->view("templates/header",$data);
        $this->view("menu/submenu",$data);
        $this->view("templates/footer",$data);
        
        
        if (isset($_POST["add"])) {
            $this->model("Menu_model")->insertsubmenu($_POST);
        }elseif (isset($_POST["edit"])) {
          $this->model("Menu_model")->updatesubmenu($_POST);
        }elseif (isset($_POST["delete"])) {
            $this->model("Menu_model")->deletesubmenu($_POST);
        }
    }
    
}