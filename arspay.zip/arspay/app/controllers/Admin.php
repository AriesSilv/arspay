<?php
class Admin extends Controller{
    public function __construct(){
        parent::__construct();
        $this->is_loggin();
        $this->is_menu();
    }
    public function Index(){
        $data["title"] = "Dashboard";
        $data["user"] = $this->userdata;
        
        $this->view("templates/header",$data);
        $this->view("admin/index",$data);
        $this->view("templates/footer",$data);
    }
    public function Users(){
        $data["title"] = "Users Management";
        $data["user"] = $this->userdata;
        $data["users"] = $this->model("User_model")->getuser();
        
        $this->view("templates/header",$data);
        $this->view("admin/users",$data);
        $this->view("templates/footer",$data);
        if (isset($_POST["add"])) {
            $this->model("Admin_model")->insertuser($_POST);
        }elseif (isset($_POST["edit"])) {
            $this->model("Admin_model")->updateuser($_POST);
        }elseif (isset($_POST["delete"])) {
            $this->model("Admin_model")->deleteuser($_POST);
        }elseif (isset($_POST["reset"])) {
            $this->model("User_model")->change_password($_POST,"Admin/Users");
        }
    }
    public function Role(){
        $data["title"] = "Role";
        $data["user"] = $this->userdata;
        $data["role"] = $this->model("Admin_model")->getrole();
        
        $this->view("templates/header",$data);
        $this->view("admin/role",$data);
        $this->view("templates/footer",$data);
        if (isset($_POST["add"])) {
            $this->model("Admin_model")->insertrole($_POST);
        }elseif (isset($_POST["edit"])) {
            $this->model("Admin_model")->updaterole($_POST);
        }elseif (isset($_POST["delete"])) {
            $this->model("Admin_model")->deleterole($_POST);
        }
    }
    public function Access($id){
        $id = urldecode(base64_decode($id));
        $data["title"] = "Access";
        $data["user"] = $this->userdata;
        $this->db->query("SELECT * FROM `user_menu` WHERE `id` != 1");
        $data["menu"] = $this->db->row_array();
        $this->db->get_where("user_role",["id" => $id]);
        $data["role"] = $this->db->row();
        $this->view("templates/header",$data);
        $this->view("admin/access",$data);
        $this->view("templates/footer",$data);
    }
    public function Notifcenter(){
        $data["title"] = "Notif Center";
        $data["user"] = $this->userdata;
        $data["notif"] = $this->model("Admin_model")->getnotif();
        
        $this->view("templates/header",$data);
        $this->view("admin/notif",$data);
        $this->view("templates/footer",$data);
        if (isset($_POST["add"])) {
            $this->model("Admin_model")->insertnotif($_POST);
        }elseif (isset($_POST["edit"])) {
            $this->model("Admin_model")->updatenotif($_POST);
        }elseif (isset($_POST["delete"])) {
            $this->model("Admin_model")->deletenotif($_POST);
        }
    }
}