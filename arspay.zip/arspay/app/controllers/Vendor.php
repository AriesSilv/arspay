<?php
class Vendor extends Controller{
    public function getbyid(){
        if (isset($_POST["name"]) && isset($_POST["id"])) {
            echo json_encode($this->model("Vendor_model")->getbyid($_POST));
        }
    }
    public function icon(){
        
        $icon = $this->model("Vendor_model")->search_icon($_POST["keyword"]);
        
        
        $this->view("vendor/icon",$icon);
        
    }
    public function get_data(){
        if (isset($_POST["get"])) {
        $tbl = $_POST["get"];
        $query = "SELECT * FROM `$tbl`";
        $this->db->query($query);
        echo json_encode($this->db->row_array());
        }
        
    }
    public function change_access(){
        $m = $_POST["menu_id"];
        $r = $_POST["role_id"];
        $data = [
            "role_id" => $r,
            "menu_id" => $m
            ];
        $this->db->get_where("user_access_menu",$data);
        if ($this->db->row_count() < 1) {
            $this->db->insert("user_access_menu",$data);
        }else{
            $this->db->Delete("user_access_menu",$data);
        }
    }
    public function change_submenu_active(){
        $is_active = $_POST["is_active"];
        $id = $_POST["id"];
        $where = ["id" => $id];
        
        if ($is_active < 1) {
            $data = ["is_active" => 1];
            $this->db->update("user_submenu",$data,$where);
        }else{
            $data = ["is_active" => 0];
            $this->db->update("user_submenu",$data,$where);
        }
    }
    public function change_user_active(){
        $is_active = $_POST["is_active"];
        $id = $_POST["id"];
        $where = ["id" => $id];
        
        if ($is_active < 1) {
            $data = ["is_active" => 1];
            $this->db->update("user",$data,$where);
        }else{
            $data = ["is_active" => 0];
            $this->db->update("user",$data,$where);
        }
    }
    public function role_default(){
        $role_default = $_POST["role_default"];
        $id = $_POST["id"];
        $where = ["id" => $id];
        if ($role_default < 1) {
            $query = "UPDATE `user_role` SET `is_default` = 0 WHERE `is_default` = 1";
            $this->db->query($query);
            $this->db->row_count();
            $this->db->update("user_role",["is_default"=>1],$where);
        }else {
            $this->db->update("user_role",["is_default"=>0],$where);
        }
    }
    public function send_otp(){
        $this->db->get_where("merchant",["m_id" => strtoupper($_POST["m_id"])]);
        $m = $this->db->row();
        if ($m) {
        $_POST["email_primary"] = $m["primary_email"];
        
        echo $this->model("Vendor_model")->send_otp($_POST);
        }else{
            echo json_encode(["result"=>false]);
        }
        
 
    }
    public function exitmerchant($email){
        $email = base64_decode($email);
        
        $this->db->get_where("merchant",["primary_email"=>$email]);
        $merchant = $this->db->row();
        if ($merchant) {
            $this->db->get_where("user",["m_id"=>$merchant["id"]]);
            $user = $this->db->row_count();
            if ($user > 1) {
            Flasher::setFlash("danger","Exit failed","Exit merchant failed");
            $this->redirect("Merchant/Merchantsettings");
            }else{
            $this->db->update("user",["m_id"=>0],["email"=>$email]);
            $this->db->update("merchant",["is_active"=>0],["id"=>$merchant["id"]]);
            
            Flasher::setFlash("success","Exit success","Exit merchant successfuly");
            $this->redirect("Merchant");
            }
            exit;
        }else{
            $this->db->update("user",["m_id"=>0],["email"=>$email]);
            Flasher::setFlash("success","Exit success","Exit merchant successfuly");
            $this->redirect("Merchant");
        }
        
    }
    public function transaction_detail($id = null){
        $data["title"] = "Transaction Detail";
        if (is_null($id)){
            $data["transaction"] = false;
        }else {
            $data["transaction"] = $this->model("Vendor_model")->gettransaction($id);
        }
        if (isset($_POST["submit"])) {
            $data["transaction"] = $this->model("Vendor_model")->gettransaction($_POST["search"]);
        }
        
        $this->view("vendor/transaction",$data);
    }
}