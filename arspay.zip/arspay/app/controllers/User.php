<?php
class User extends Controller{
    public function __construct(){
        parent::__construct();
        $this->is_loggin();
        $this->is_menu();
    }
    public function Index(){
        $data["title"] = "My Profile";
        $data["user"] = $this->userdata;
        $this->view("templates/header",$data);
        $this->view("user/index",$data);
        $this->view("templates/footer",$data);
        
    }
    public function Editprofile(){
        
        $data["title"] = "Edit Profile";
        $data["user"] = $this->userdata;
        $this->view("templates/header",$data);
        $this->view("user/edit_profile",$data);
        $this->view("templates/footer",$data);
        if (isset($_POST["edit_profile"])) {
            $this->model("User_model")->editprofile($_POST);
        }
    }
    public function Changepassword(){
        
        $data["title"] = "Change Password";
        $data["user"] = $this->userdata;
        $this->view("templates/header",$data);
        $this->view("user/change_password",$data);
        $this->view("templates/footer",$data);
        
        if (isset($_POST["change_password"])) {
            $this->model("User_model")->change_password($_POST,"User/Changepassword",$data["user"]);
        }
    }
}