<?php
class Auth extends Controller{
    public function not_loggin(){
        if (isset($_SESSION["user"])) {
            
            $this->redirect("User");
        }
    }
    public function Index(){
        $this->not_loggin();
        $data["title"] = "Login";
        $this->view("templates/auth_header",$data);
        $this->view("auth/login",$data);
        $this->view("templates/auth_footer");
        
        
        if (isset($_POST["submit"])) {
            
            $this->model("Auth_model")->login($_POST);
        }
    }
    public function Register(){
        $this->not_loggin();
        $data["title"] = "Register";
        
        
        $this->view("templates/auth_header",$data);
        $this->view("auth/register",$data);
        $this->view("templates/auth_footer");
        
        if (isset($_POST["submit"])) {
            
            $this->model("Auth_model")->register($_POST);
        }
        
    }
    public function Logout(){
        unset($_SESSION["user"]);
        Flasher::setFlash("success","Logout success.","You have logged out");
        $this->redirect("Auth");
    }
    public function Blocked(){
        
        $data["user"] = $this->userdata;
        $this->view("templates/header",$data);
        $this->view("auth/blocked",$data);
        $this->view("templates/footer");
    }
    public function Notfound(){
        $data["user"] = $this->userdata;
        $this->view("templates/header",$data);
        $this->view("auth/notfound",$data);
        $this->view("templates/footer");
    }
    public function Verify($email,$token){
        $data["email"] = urldecode(base64_decode($email));
        $data["token"] = urldecode($token);
        
        $this->model("Auth_model")->verify_account($data);
    }
    public function Forgotpassword(){
        $this->not_loggin();
        $data["title"] = "Forgot Password";
        
        
        $this->view("templates/auth_header",$data);
        $this->view("auth/forgot",$data);
        $this->view("templates/auth_footer");
        if (isset($_POST["submit"])) {
            
            $this->model("Auth_model")->forgot_password($_POST);
        }
    }
    public function Resetpassword($email,$token){
        $data["email"] = urldecode(base64_decode($email));
        $data["token"] = urldecode($token);
        $this->model("Auth_model")->reset_password($data);
    }
    public function Sessionresetpassword(){
        if (!isset($_SESSION["reset_email"])) {
            
            $this->redirect("Auth");
            exit;
        }
        $data["email"] = base64_decode($_SESSION["reset_email"]);
        $data["title"] = "Reset password for";
        
        
        $this->view("templates/auth_header",$data);
        $this->view("auth/reset",$data);
        $this->view("templates/auth_footer");
        if (isset($_POST["submit"])) {
            $_POST["email"] = $data["email"];
            $this->model("Auth_model")->reset_password_session($_POST);
        }
    }
}