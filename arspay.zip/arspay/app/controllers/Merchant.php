<?php
class Merchant extends Controller{
    public function __construct(){
        parent::__construct();
        $this->is_loggin();
        $this->is_menu();
    }
    public function premerchant(){
        $user = $this->userdata;
        if ($user["m_id"] < 1) {
            $this->redirect("Merchant");
            exit;
        }
    }
    public function Index(){
        $data["title"] = "Merchant Dashboard";
        
        $dbi = new Database("vendor");
        $dbi->query("SELECT * FROM `bank` ORDER BY `bank_id` ASC");
        $data["bank"] = $dbi->row_array();
        
        $data["user"] = $this->userdata;
        $data["merchant"] = $this->model("Merchant_model")->getmerchantbyid($data["user"]["m_id"]);
        
        $data["transaction"] = $this->model("Merchant_model")->gettransaction($data["merchant"]["m_id"]);
        
        $this->view("templates/header",$data);
        if ($data["user"]["m_id"] < 1) {
        $this->view("merchant/addmerchant",$data);
        }else{
            $this->view("merchant/index",$data);
        }
        
        $this->view("templates/footer",$data);
        if (isset($_POST["create"])) {
            $this->model("Merchant_model")->create_merchant($_POST);
        }
        if (isset($_POST["join"])) {
            $this->model("Merchant_model")->join_merchant($_POST);
        }
        
    }
    public function Billing(){
        $this->premerchant();
        $data["title"] = "Billing";
        
        $data["user"] = $this->userdata;
        
        $data["merchant"] = $this->model("Merchant_model")->getmerchantbyid($data["user"]["m_id"]);
        $data["billing"] = $this->model("Merchant_model")->getbilling($data["merchant"]["m_id"]);
        
        $this->view("templates/header",$data);
        $this->view("merchant/billing",$data);
        $this->view("templates/footer",$data);
        if (isset($_POST["add"])) {
            $this->model("Merchant_model")->insertbill($_POST);
        }/*
        if (isset($_POST["edit"])) {
            $this->model("Merchant_model")->updatebill($_POST);
        }*/
        if (isset($_POST["delete"])) {
            $this->model("Merchant_model")->deletebill($_POST);
        }
        
    }
    public function Merchantsettings(){
        $this->premerchant();
        $data["title"] = "Merchant Settings";
        $data["user"] = $this->userdata;
        $data["merchant"] = $this->model("Merchant_model")->getmerchantbyid($data["user"]["m_id"]);
        $data["merchant"]["bank"] = $this->model("Merchant_model")->getbank($data["merchant"]["bank_id"]);
        
        $data["bank"] = $this->model("Merchant_model")->getbank();
        $data["users"] = $this->model("Merchant_model")->getusermerchant($data["merchant"]["id"]);
        
        $this->view("templates/header",$data);
        $this->view("merchant/setting",$data);
        $this->view("templates/footer",$data);
        
        if (isset($_POST["add"])) {
            $this->model("Merchant_model")->addusermerchant($_POST);
        }
        if (isset($_POST["delete"])) {
            $this->model("Merchant_model")->deleteusermerchant($_POST);
        }
        if (isset($_POST["edit"])) {
            $this->model("Merchant_model")->updatemerchant($_POST);
        }
        
    }
    public function addtransaction($m,$b){
        $m = urldecode(base64_decode($m));
        $b = urldecode(base64_decode($b));
        
        
            $this->model("Merchant_model")->addtransaction($m,$b);
        
    }
}