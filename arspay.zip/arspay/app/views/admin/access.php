<h1 class="h3 mb-4 text-gray-800"><?=$data["title"];?></h1>
<?php Flasher::flash_message();?>
<!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row justify-content-between">
                <div class="col-xs-4">
                <h5 class="m-0 font-weight-bold text-primary card-title">Access Role <?=$data["role"]["role"];?></h5>
                </div>
                <div class="col-xs-4">
                <a href="<?=$this->base_url('Admin/Role');?>" class="badge badge-primary " >Back</a>
                </div>
            </div>
        </div>
        <div class="card-body">

                
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Menu</th>
                            <th>Access</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($data["menu"] as $m): ?>
                        <tr>
                        <td><?=$i;?></td>
                        <td><?=$m["menu"];?></td>
                        <td>

                    <label class="switch">
                    <input type="checkbox" <?=$this->model("Vendor_model")->check_access($m["id"],$data["role"]["id"]);?> class="check_access" m-id="<?=$m['id'];?>" r-id="<?=$data['role']['id'];?>">
                    <span class="slider"></span>
                    </label>

                        </td>
                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<!-- Button trigger modal -->


