<h1 class="h3 mb-4 text-gray-800"><?=$data["title"];?></h1>
<?php Flasher::flash_message();?>

<!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row justify-content-between">
                <div class="col-xs-4">
                <h5 class="m-0 font-weight-bold text-primary card-title">Data Users</h5>
                </div>
                <div class="col-xs-4">
                <a href="#" class="badge badge-primary data-modal" data-toggle="modal" data-target="#DataModal" data-action="add" data-temp="users">Add New Data</a>
                </div>
            </div>
        </div>
        <div class="card-body">

            
                
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Action</th>
                            <th>Email</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Role</th>
                            <th>Created</th>
                            <th>Active</th>
                            <th>Image</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($data["users"] as $u): ?>
                        <tr>
                        <td><?=$i;?></td>
                        <td>
                            <a href="#" class="badge rounded-pill badge-info data-modal" data-toggle="modal" data-target="#DataModal" data-action="edit" data-temp="users" data-id="<?=$u['id'];?>">Edit</a>
                                                <a href="#" class="badge rounded-pill badge-warning data-modal" data-toggle="modal" data-target="#DataModal" data-action="edit" data-temp="reset_password" data-id="<?=$u['id'];?>">Reset Password</a>
                            <a href="#" class="badge rounded-pill badge-danger data-modal" data-toggle="modal" data-target="#DataModal" data-action="delete" data-temp="users" data-id="<?=$u['id'];?>">Delete</a>
                        </td>

                        <td><?=$u["email"];?></td>
                        <td><?=$u["name"];?></td>
                        <td><?=$u["phone"];?></td>
                        <td><?=$u["role"];?></td>
                        <td><?=date("d F Y",$u["date_created"]);?></td>
                        <td class="text-center">
                    <?php if ($u["role_id"] < 2): ?>
                        <!-- html... -->
                    <?php else: ?>
                    <label class="switch">
                    <input type="checkbox" <?=$this->model("Vendor_model")->active($u["is_active"]);?> class="users_active" data-active="<?=$u['is_active'];?>" data-id="<?=$u['id'];?>">
                    <span class="slider"></span>
                    </label>
                    <?php endif; ?>
                    


                           
                        </td>
                        <td>
                            <img src="img/profile/<?=$u['image']?>" class="img-thumbnail">
                        </td>
                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<!-- Button trigger modal -->


