<h1 class="h3 mb-4 text-gray-800"><?=$data["title"];?></h1>
<?php Flasher::flash_message();?>
<!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row justify-content-between">
                <div class="col-xs-4">
                <h5 class="m-0 font-weight-bold text-primary card-title">Data Role</h5>
                </div>
                <div class="col-xs-4">
                <a href="#" class="badge badge-primary data-modal" data-toggle="modal" data-target="#DataModal" data-action="add" data-temp="role">Add New Data</a>
                </div>
            </div>
        </div>
        <div class="card-body">

                
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                                                        <th>Role Default</th>
                            <th>Role</th>
                            <th>Action</th>

                        </tr>
                    </thead>

                    <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($data["role"] as $role): ?>
                        <tr>
                        <td><?=$i;?></td>
                        <td><label class="switch">
                    <input type="checkbox" <?=$this->model("Vendor_model")->active($role["is_default"]);?> class="role_default" data-id="<?=$role['id'];?>" data-rd="<?=$role['is_default']?>">
                    <span class="slider"></span>
                    </label></td>
                        <td><?=$role["role"];?></td>
                        <td>
                            <a href="<?=$this->base_url('Admin/Access/').urlencode(base64_encode($role['id']));?>" class="badge rounded-pill badge-warning">Access</a>
                            <a href="#" class="badge rounded-pill badge-info data-modal" data-toggle="modal" data-target="#DataModal" data-action="edit" data-temp="role" data-id="<?=$role['id'];?>">Edit</a> 
                            <a href="#" class="badge rounded-pill badge-danger data-modal" data-toggle="modal" data-target="#DataModal" data-action="delete" data-temp="role" data-id="<?=$role['id'];?>">Delete</a>
                        </td>
                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<!-- Button trigger modal -->


