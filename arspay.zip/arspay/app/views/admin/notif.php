<h1 class="h3 mb-4 text-gray-800"><?=$data["title"];?></h1>

<?php Flasher::flash_message();?>
<!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row justify-content-between">
                <div class="col-xs-4">
                <h5 class="m-0 font-weight-bold text-primary card-title">Data Notification</h5>
                </div>
                <div class="col-xs-4">
                <a href="#" class="badge badge-primary data-modal" data-toggle="modal" data-target="#DataModal" data-action="add" data-temp="notif">Add New Data</a>
                </div>
            </div>
        </div>
        <div class="card-body">

                
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Notif</th>
                            <th>Notif for</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($data["notif"] as $notif): ?>
                        <tr>
                        <td><?=$i;?></td>
                        
                        <td>                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle" style="background-color: <?=$notif['color'];?>">
                                            <i class="fa-solid text-white <?=$notif['icon']?>"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500"><?=date("d F Y",$notif["date_created"]);?></div>
                                        <span class="font-weight-bold"><?=$notif["content"];?></span>
                                    </div>
                                </a>
                        </td>
                        <td><?=$notif["notif_for"];?></td>
                        <td>
                            <a href="#" class="badge rounded-pill badge-info data-modal" data-toggle="modal" data-target="#DataModal" data-action="edit" data-temp="notif" data-id="<?=$notif['id'];?>">Edit</a> 
                            <a href="#" class="badge rounded-pill badge-danger data-modal" data-toggle="modal" data-target="#DataModal" data-action="delete" data-temp="notif" data-id="<?=$notif['id'];?>">Delete</a>
                        </td>
                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<!-- Button trigger modal -->


