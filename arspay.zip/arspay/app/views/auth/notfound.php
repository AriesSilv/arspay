                    <!-- 404 Error Text -->
                    <div class="text-center">
                        <div class="error mx-auto" data-text="404">404</div>
                        <p class="lead text-gray-800 mb-0">Not Found</p>
                        <p class="text-gray-500 mb-5">The requested menu was not found</p>
                        <a href="<?=$this->base_url("User");?>">&larr; Back to Dashboard</a>
                    </div>