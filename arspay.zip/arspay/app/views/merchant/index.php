<h1 class="h3 mb-4 text-gray-800"><?=$data["title"];?></h1>
<?php Flasher::flash_message();?>
<div class="card shadow mb-4">
        <div class="card-header py-3">

                <h5 class="m-0 font-weight-bold text-primary card-title">Transaction List</h5>
                

        </div>
        <div class="card-body">

                
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>

<th>Date Created</th>
                            <th>Transaction_id</th>
                            <th>Title</th>
                            <th>Cost</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($data["transaction"] as $transaction): ?>
                        <tr>
                                          <td><?=date("d F Y",$transaction["date_created"]);?></td>
                        <td><?=$transaction["m_id"];?>-<?=$transaction["b_id"];?>-<?=$transaction["transaction_id"];?></td>
                                          <td><?=$transaction["title"];?></td>

                        <td>Rp.<?=number_format($transaction["cost"],0,".",".");?></td>
                        <td>
<?php if ($transaction["status"] >0): ?>
    <span class="badge badge-pill badge-success">Success</span>
<?php else: ?>
    <span class="badge badge-pill badge-secondary">Pending</span>
<?php endif; ?>


                        </td>
                        <td><a href="<?=$this->base_url('Vendor/transaction_detail/'.$transaction['transaction_id']);?>" class="badge badge-info">Visit Link</a></td>
                        </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>