<h1 class="h3 mb-4 text-gray-800"><?=$data["title"];?></h1>

<?php Flasher::flash_message();?>
<a href="#" class="btn btn-secondary mb-4 data-modal" data-toggle="modal" data-target="#DataModal" data-action="edit" data-temp="merchantcogs" data-email="<?=$data['user']['email'];?>"><i class="fa-solid fa-cog"></i></a>
<!-- DataTales Example -->
<div class="card mb-4">
    <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-primary card-title"><?=$data["merchant"]["merchant"];?></h5>
    </div>
    <div class="card-body">
    <form action="" method="post">
        
    <div class="form-group">
        <label for="merchant_id" class="form-label">Merchant ID</label>
        <input type="hidden" name="m_id" value="<?=$data['merchant']['m_id'];?>">
        <input type="text" class="form-control" id="merchant_id" maxlength="3" name="merchant_id" value="<?=$data['merchant']['m_id'];?>">
        <span class="form-text">3 letter long and uppercase</span>
    </div>
    <div class="form-group">
        <label for="merchant" class="form-label">Merchant</label>
        <input type="text" class="form-control" id="merchant" name="merchant" value="<?=$data['merchant']['merchant'];?>">
    </div>
    <div class="form-group">
        <label for="bank" class="form-label">Bank</label>
<select name="bank" class="form-control" id="bank">
  <option value="<?=$data['merchant']['bank_id'];?>" selected><?=$data["merchant"]["bank"];?></option>
  <?php foreach ($data["bank"] as $bank): ?>
  <option value="<?=$bank['bank_id'];?>"><?=$bank["bank"];?></option>
  <?php endforeach; ?>

</select>
    </div>
    
    <div class="form-group">
        <label for="bank_account" class="form-label">Bank Account</label>
        <input type="tel" class="form-control" id="bank_account" name="bank_account" value="<?=$data['merchant']['bank_account'];?>">
    </div>
    <button type="submit" class="btn btn-primary btn-user btn-block" name="edit">
                                            Edit
                                        </button>
    </form> 
    </div>

</div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row justify-content-between">
                <div class="col-xs-4">
                <h5 class="m-0 font-weight-bold text-primary card-title">Data Users</h5>
                </div>
                <div class="col-xs-4">
                <?php if ($data["user"]["email"] == $data["merchant"]["primary_email"]): ?>
                <a href="#" class="badge badge-primary data-modal" data-toggle="modal" data-target="#DataModal" data-action="add" data-temp="usermerchant" m-id="<?=$data['merchant']['id'];?>">Add New Data</a>
<?php endif; ?>

                </div>
            </div>
        </div>
        <div class="card-body">

            
                
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            
                            <th>Action</th>
                            <th>Email</th>
                            <th>Name</th>
                            <th>Phone</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($data["users"] as $u): ?>
                    <?php if ($u["email"] != $data["merchant"]["primary_email"]): ?>
                        <tr>
                        <td><?=$i;?></td>
                        <td>
<?php if ($data["user"]["email"] == $data["merchant"]["primary_email"]): ?>
                            <a href="#" class="badge rounded-pill badge-danger data-modal" data-toggle="modal" data-target="#DataModal" data-action="delete" data-temp="usermerchant" data-id="<?=$u['email'];?>">Delete</a>
<?php endif; ?>

                        </td>

                        <td><?=$u["email"];?></td>
                        <td><?=$u["name"];?></td>
                        <td><?=$u["phone"];?></td>

                        </tr>
                    <?php endif; ?>


                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<!-- Button trigger modal -->


