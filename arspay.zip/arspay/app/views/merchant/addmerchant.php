<h1 class="h3 mb-4 text-gray-800"><?=$data["title"];?></h1>
<?php Flasher::flash_message();?>
<div class="card mb-4">
  <h5 class="card-header">Create Merchant</h5>
  <div class="card-body">
      <form action="" method="post">
    <div class="form-group">
        <input type="hidden" name="primary_email" value="<?=$data['user']['email'];?>">
        <label for="merchant_id" class="form-label">Merchant ID</label>
        <input type="text" class="form-control" id="merchant_id" maxlength="3" name="merchant_id">
        <span class="form-text">3 letter long and uppercase</span>
    </div>
    <div class="form-group">
        <label for="merchant" class="form-label">Merchant</label>
        <input type="text" class="form-control" id="merchant" name="merchant">
    </div>
    <div class="form-group">
        <label for="bank" class="form-label">Bank</label>
<select name="bank" class="form-control" id="bank">
  <option value="0" selected>Open this select bank</option>
  <?php foreach ($data["bank"] as $bank): ?>
  <option value="<?=$bank['bank_id'];?>"><?=$bank["bank"];?></option>
  <?php endforeach; ?>

</select>
    </div>
    
    <div class="form-group">
        <label for="bank_account" class="form-label">Bank Account</label>
        <input type="tel" class="form-control" id="bank_account" name="bank_account">
    </div>
    <button type="submit" class="btn btn-primary btn-user btn-block" name="create">
                                            Create
                                        </button>
    </form> 
  </div>
</div>
<div class="card">
  <h5 class="card-header">Join Merchant</h5>
  <div class="card-body">
      <form action="" method="post">
    <div class="form-group">
                <input type="hidden" name="primary_email" value="<?=$data['user']['email'];?>">
        <label for="m-id" class="form-label">Merchant ID</label>
        <input type="text" class="form-control" id="m-id" maxlength="3" name="merchant_id">
        <span class="form-text">3 letter long and uppercase</span>
    </div>
    <div class="form-group">
        <label for="otp" class="form-label">OTP</label>
        <div class="input-group mb-4">
            <input type="text" class="form-control" aria-describedby="button-addon2" id="otp" maxlength="6" name="otp">
            <button class="btn btn-outline-primary send_otp" type="button" data-email="<?=$data['user']['email'];?>">Send OTP</button>
        </div>
    </div>
<button type="submit" class="btn btn-primary btn-user btn-block" name="join">
                                            Join
                                        </button>
    </form>
    </div>
    </div>

