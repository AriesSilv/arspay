<!DOCTYPE html>
<html lang="en">

<head>


    <title>Arspay - <?=$data["title"];?></title>

    <!-- Custom fonts for this template-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    
    <!-- Custom styles for this template-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/arspay.css" rel="stylesheet">
    <script type="text/javascript"
      src="<?=$this->config->midtrans['url'];?>"
      data-client-key="<?=$this->config->midtrans['clientkey'];?>"></script>
</head>

<body id="page-top" data-url="<?=$this->base_url('');?>">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <?php $this->view("templates/sidebar",$data);?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                    <?php $this->view("templates/topbar",$data);?>
                <!-- Begin Page Content -->
                <div class="container-fluid">