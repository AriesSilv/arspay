        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?=$this->base_url('');?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fa-solid fa-file-invoice-dollar"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Arspay</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider mt-0">

            <?php
            
            $menu = $this->model("Menu_model")->nav_menu($data["user"]["role_id"]);
            ?>
            <!-- menu -->
            <?php foreach ($menu as $m): ?>
            <div class="sidebar-heading">
                <?=$m["menu"]?>
            </div>
            <?php
            $submenu = $this->model("Menu_model")->nav_submenu($m["id"]);
            ?>
            <?php foreach ($submenu as $sm): ?>
            <?php if (isset($data["title"]) AND $sm["submenu"] == $data["title"]): ?>
            <li class="nav-item active">
            <?php else: ?>
            <li class="nav-item">
            <?php endif; ?>
            

                <a class="nav-link" href="<?=$this->base_url($sm['url']);?>">
                    <i class="fa-solid fa-fw <?=$sm['icon'];?>"></i>
                    <span><?=$sm["submenu"];?></span></a>
            </li>
            <?php endforeach; ?>
            <!-- Divider -->
            <hr class="sidebar-divider">
            <?php endforeach; ?>

            <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="fa-solid fa-sign-out-alt fa-fw"></i>
                    <span>Logout</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->