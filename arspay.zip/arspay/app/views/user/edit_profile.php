<h1 class="h3 mb-4 text-gray-800"><?=$data["title"];?></h1>
<?php Flasher::flash_message();?>
<div class="row">
    <div class="col-lg-8">
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group row">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="hidden" id="is_image" name="is_image" class="form-control" value="<?=$data['user']['image'];?>">
                    <input type="text" id="email" name="email" class="form-control" value="<?=$data['user']['email'];?>" readonly>
                </div>
            </div>
            <div class="form-group row">
                <label for="name" class="col-sm-2 col-form-label">Name</label>
                <div class="col-sm-10">
                    <input type="text" id="name" name="name" class="form-control" value="<?=$data['user']['name'];?>">
                    <small class="text-danger"><?=Flasher::form_error("name");?></small>
                </div>
            </div>
            <div class="form-group row">
                <label for="phone" class="col-sm-2 col-form-label">Phone</label>
                <div class="col-sm-10">
                    <input type="tel" id="phone" name="phone" class="form-control" value="<?=$data['user']['phone'];?>">
                    <small class="text-danger"><?=Flasher::form_error("phone");?></small>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">
                    Picture
                </div>
                <div class="col-sm-10">
                    <div class="row">
                        <div class="col-sm-3">
                            <img src="img/profile/<?=$data['user']['image']?>" class="img-thumbnail">
                        </div>
                        <div class="col-sm-9">
                            <div class="custom-file">
                               <input type="file" class="custom-file-input" id="image" name="image">
                               <label for="image" class="custom-file-label">Choose file</label>
                               <small class="text-danger"><?=Flasher::form_error("image");?></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group row justify-content-end">
                <div class="col-sm-10">
                    <button class="btn btn-primary" name="edit_profile" type="submit">Edit</button>
                </div>
            </div>
        </form>
    </div>
</div>