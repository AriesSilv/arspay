<?php
class Auth_model extends Model{
    public function register($data){
        $lib = $this->library("Form_Validation");
        $lib->set_data($data);
        
        $lib->set_rules("name",["trim","require","min"=>3,"max"=> 20]);
        $lib->set_rules("email",["trim","require","email_valid","in_db" => "user/email/false"]);
        $lib->set_rules("password",["trim","require","min" => 6,"matches"=>"repassword"]);
        $lib->set_rules("repassword",["trim","require","min" => 6,"matches"=>"password"]);
        
        if ($lib->run() == false) {
            $this->redirect("Auth/Register");
            exit;
        }
        $name = htmlspecialchars($lib->get_data("name"));
        $email = htmlspecialchars($lib->get_data("email"));
        $pass = password_hash($lib->get_data("password"),PASSWORD_DEFAULT);
        $this->db->get_where("user_role",["is_default"=>1]);
            $rr = $this->db->row();
            $role = $rr["id"];
        $user_data = [
            "name" => $name,
            "email" => $email,
            "phone" => "",
            "image" => "default.jpg",
            "password" => $pass,
            "role_id" => $role,
            "m_id" => 0,
            "is_active" => 0,
            "date_created" => time()
            ];
        $token = base64_encode(random_bytes(8));
        
        $user_token = [
                "email" => $email,
                "token" => $token,
                "date_created" => time()
            ];
        
        
        if ($this->db->insert("user",$user_data) > 0) {
            $this->db->insert("user_token",$user_token);
            $this->library("Mail");
            $this->lib->to = htmlspecialchars_decode($email);
            $this->lib->subject = "Account Verification";
            $this->lib->head = '<h1 style="font-size: 14px;">Welcome to Arspay</h1>'.$email;
            $email = urlencode(base64_encode($email));
            $token = urlencode($token);
            
    $this->lib->body = '          
    <p class="text-left" style="text-align:left;">Hi '.htmlspecialchars_decode($name).', Thank for joining Arspay. Verify your account to start using arspay.</p>
          <a href="'.$this->base_url("Auth/Verify/".$email."/".$token).'" class="btn btn-primary" style="display: inline-block;
  padding: 6px;
  color: #ffffff;
  text-align: center;
  border: 1px double #cccccc;
  border-radius: 5px;
  font-size: 10px;
  cursor: pointer; /* add this line */
  text-decoration: none;
  background-color: #0d6efd;">Account verification</a>';
  Flasher::setFlash("info","Registration success.","Your account has been created, verify your account via email.");
            $this->lib->reddir = $this->base_url("Auth");
            $this->lib->send();
            

        }else{
            Flasher::setFlash("danger","Registration failed.","Check your data again");
            $this->redirect("Auth/Register");
        }
    }
    public function login($data){
        $lib = $this->library("Form_Validation");
        $lib->set_data($data);
        
        
        $lib->set_rules("email",["trim","require","email_valid","in_db" => "user/email/true"]);
        $lib->set_rules("password",["require","min" => 6,"trim"]);
        
        if ($lib->run() == false) {
            $this->redirect("Auth");
            exit;
        }
        $email = $lib->get_data("email");
        $password = $lib->get_data("password");
        $this->db->get_where("user",["email" => $email]);
        $user = $this->db->row();
        
        if ($user) {
            $lib->set_rules("password",["password_verify"=>$user["password"]]);
        
            if ($lib->run() == false) {
            $this->redirect("Auth");
            exit;
            }
            if ($user["is_active"] > 0) {
                
                if ($user["role_id"] > 1) {
                $_SESSION["user"] = [
                        "email" => $user["email"]];
                
                        $this->redirect("User");
                }else {
                        $_SESSION["user"] = [
                        "email" => $user["email"]];
                        
                        $this->redirect("Admin");
                }
                    
                    
                        

            }else {
                Flasher::setFlash("danger","Login failed.","Your account is inactive or deactivated.");
                $this->redirect("Auth");
            }
        }else{
            Flasher::setFlash("danger","Login failed.","Your email not registered");
            $this->redirect("Auth");
        }
    }
    public function verify_account($data){
        $email = $data["email"];
        $token = $data["token"];
        $this->db->get_where("user",["email" => $email]);
        $user = $this->db->row();
        if ($user) {
            $this->db->get_where("user_token",["token"=>$token]);
            $user_token = $this->db->row();
            if ($user_token) {
                if (time() - $user_token["date_created"] < (60*60*24)) {
                    $this->db->update("user",["is_active" =>1],["email" => $email]);
                    $this->db->Delete("user_token",["email" =>$email]);
                    Flasher::setFlash("success","Account verification success.","Please loggin");
            $this->redirect("Auth");
                } else {
                $this->db->Delete("user",["email" =>$email]);
                $this->db->Delete("user_token",["email" =>$email]);
            Flasher::setFlash("danger","Account verification failed.","Token expired");
            $this->redirect("Auth");
                }
                
            } else {
            Flasher::setFlash("danger","Account verification failed.","Invalid token");
            $this->redirect("Auth");
            }
            
        } else {
            Flasher::setFlash("danger","Account verification failed.","Wrong email");
            $this->redirect("Auth");
        }
        
    }
    public function forgot_password($data){
        $lib = $this->library("Form_Validation");
        $lib->set_data($data);
        $lib->set_rules("email",["trim","require","email_valid","in_db" => "user/email/true"]);
        if ($lib->run() == false) {
            $this->redirect("Auth/Forgotpassword");
            exit;
        }
        $email = $lib->get_data("email");
        
        $this->db->get_where("user",["email" => $email,"is_active" =>1]);
        $user = $this->db->row();
        if ($user) {
            $token = base64_encode(random_bytes(8));
            $this->db->Delete("user_token",["email"=>$email]);
            $user_token = [
                "email" => $email,
                "token" => $token,
                "date_created" => time()
                ];
            $this->db->insert("user_token",$user_token);
            $this->library("Mail");
            $this->lib->to = htmlspecialchars_decode($email);
            $this->lib->subject = "Forgot Password";
            $this->lib->head = '<h1 style="font-size: 14px;">Reset Password</h1>'.$email;
            $email = urlencode(base64_encode($email));
            $token = urlencode($token);
            
    $this->lib->body = '          
    <p class="text-left" style="text-align:left;">Hi '.$user["name"].', Did you forgot the password? Click the button below to reset the password.</p>
          <a href="'.$this->base_url("Auth/Resetpassword/".$email."/".$token).'" class="btn btn-primary" style="display: inline-block;
  padding: 6px;
  color: #ffffff;
  text-align: center;
  border: 1px double #cccccc;
  border-radius: 5px;
  font-size: 10px;
  cursor: pointer; /* add this line */
  text-decoration: none;
  background-color: #0d6efd;">Reset Password</a>';
  Flasher::setFlash("success","Request forgot password success.","Please check your email. click if not receiving email <a href='#' class='aleart-link'>Send Email</a>");
            $this->lib->reddir = $this->base_url("Auth/Forgotpassword");
            $this->lib->send();
        }else{
            Flasher::setFlash("danger","Request forgot password failed.","Email unregistered or inactive ");
            $this->redirect("Auth");
        }
    }
    public function reset_password($data){
        $email = $data["email"];
        $token = $data["token"];
        $this->db->get_where("user",["email" => $email]);
        $user = $this->db->row();
        if ($user) {
            $this->db->get_where("user_token",["token"=>$token]);
            $user_token = $this->db->row();
            if ($user_token) {
                if (time() - $user_token["date_created"] < (60*60*24)) { $_SESSION["reset_email"] = base64_encode($user["email"]);
                    $this->db->Delete("user_token",["email" =>$email]);
                    $this->redirect("Auth/Sessionresetpassword");
                } else {
                
                $this->db->Delete("user_token",["email" =>$email]);
            Flasher::setFlash("danger","Reset password fialed.","Token expired");
            $this->redirect("Auth/Forgotpassword");
                }
                
            } else {
            Flasher::setFlash("danger","Reset password failed.","Invalid token");
            $this->redirect("Auth/Forgotpassword");
            }
            
        } else {
            Flasher::setFlash("danger","Reset password failed.","Wrong email");
            $this->redirect("Auth/Forgotpassword");
        }
    }
    public function reset_password_session($data){
        $lib = $this->library("Form_Validation");
        $lib->set_data($data);
        
        
        
        $lib->set_rules("password",["trim","require","min" => 6,"matches"=>"repassword"]);
        $lib->set_rules("repassword",["trim","require","min" => 6,"matches"=>"password"]);
        
        if ($lib->run() == false) {
            $this->redirect("Auth/Sessionresetpassword");
            exit;
        }
        $email = $data["email"];
        $pass = password_hash($lib->get_data("password"),PASSWORD_DEFAULT);
        $this->db->update("user",["password"=>$pass],["email" =>$email]);
        unset($_SESSION["reset_email"]);
        Flasher::setFlash("success","Reset password success.","Please login");
            $this->redirect("Auth");
    }
    
}