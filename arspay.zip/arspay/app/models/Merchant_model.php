<?php
class Merchant_model extends Model{
    public function getmerchantbyid($id){
        $data = ["id"=>$id];
        $this->db->get_where("merchant",$data);
        return $this->db->row();
    }
    public function getbilling($id){
        $data = ["merchant"=>$id];
        $this->db->get_where("billing",$data);
        return $this->db->row_array();
    }
    public function getbank($id = null){
        $dbi = new Database("vendor");
        if (is_null($id)) {
            $dbi->get("bank");
            return $dbi->row_array();
        }else{
            $query = "SELECT `bank` FROM `bank` WHERE `bank_id` = :id";
            $dbi->query($query);
            $dbi->bind("id",$id);
            $bank = $dbi->row();
            return $bank["bank"];
        }
    }
    public function create_merchant($data){
        strtoupper($data["merchant_id"]);
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("merchant_id",["trim","require","max"=>3,"min"=>3,"in_db" => "merchant/m_id/false"],true);
        $this->lib->set_rules("primary_email",["in_db" => "merchant/primary_email/false"],true);
        $this->lib->set_rules("merchant",["trim","require"],true);
        $this->lib->set_rules("bank_account",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Merchant");
            exit;
        }
        if ($data["bank"] < 1){
            Flasher::setFlash("danger","Insert Failed","Bank Required");
            $this->redirect("Merchant");
        }
        $m_id = strtoupper($this->lib->get_data("merchant_id"));
        $email = $data["primary_email"];
        $u_data = [
            "m_id" => $m_id,
            "merchant" => $this->lib->get_data("merchant"),
            "primary_email" => $email,
            "bank_id" => $data["bank"],
            "bank_account" => $this->lib->get_data("bank_account"),
            "is_active" => 1
            ];
            if ($this->db->insert("merchant",$u_data) > 0) {
                $this->db->get_where("merchant",["m_id"=>$m_id]);
                $m = $this->db->row();
                
                if ($this->db->update("user",["m_id"=>$m["id"]],["email"=>$email])) {
Flasher::setFlash("success","Insert Success","Merchant success to add");
                $this->redirect("Merchant");
                }else {
                Flasher::setFlash("danger","Update Failed","User failed to update");
                $this->redirect("Merchant");
                }
            }else {
            Flasher::setFlash("danger","Insert Failed","Merchant failed to add");
            $this->redirect("Merchant");
            }
            
        
    }
    public function join_merchant($data){
        
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("merchant_id",["trim","require","max"=>3,"min"=>3,"in_db" => "merchant/m_id/true"],true);
        $this->lib->set_rules("otp",["trim","require","max"=>6,"min"=>6],true);
        $this->lib->set_rules("primary_email",["in_db" => "merchant/primary_email/false"],true);

        if ($this->lib->run() == false) {
            $this->redirect("Merchant");
            exit;
        }
        $email = $this->lib->get_data("primary_email");
        $m_id = strtoupper($this->lib->get_data("merchant_id"));
        $otp = $this->lib->get_data("otp");
        $this->db->get_where("merchant",["m_id"=>$m_id]);
        $mer = $this->db->row();
        
        $this->db->get_where("user_token",["email"=>$email,"token"=>$otp]);
        $user = $this->db->row();
        if ($user) {
            if (time() - $user["date_created"] < (60*60*24)) {
                $this->db->update("user",["m_id"=>$mer["id"]],["email"=>$email]);
                $this->db->Delete("user_token",["email" =>$email]);
                Flasher::setFlash("success","Merchant authorization success","Join merchant successfuly");
                $this->redirect("Merchant");
            }else {
                $this->db->Delete("user_token",["email" =>$email]);
            Flasher::setFlash("danger","Merchant authorization failed","OTP expired");
            $this->redirect("Merchant");
            }
        }else{
            Flasher::setFlash("danger","Merchant authorization failed","Wrong OTP");
            $this->redirect("Merchant");
        }
        
    }
    public function insertbill($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("billing_id",["trim","require"],true);
        $this->lib->set_rules("billing",["trim","require"],true);
        $this->lib->set_rules("cost",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Merchant/Billing");
            exit;
        }
        $b_id = strtoupper($this->lib->get_data("billing_id"));
        $merchant = $data["merchant"];
        $this->db->get_where("billing",[
            "merchant"=>$merchant,
            "b_id"=>$b_id
            ]);
        if ($this->db->row_count() > 0) {
            Flasher::setFlash("danger","Insert failed","Billing ID is exists");
            $this->redirect("Merchant/Billing");
        }
        $bill = [
            "merchant"=>$merchant,
            "b_id"=>$b_id,
            "billing"=>$this->lib->get_data("billing"),
            "cost"=>$this->lib->get_data("cost")
            ];
        if ($this->db->insert("billing",$bill) > 0) {
            Flasher::setFlash("success","Insert success","Billing added successfuly");
            $this->redirect("Merchant/Billing");
        }else {
            Flasher::setFlash("danger","Insert failed","Billing failed to add");
            $this->redirect("Merchant/Billing");
        }
    }
    public function updatebill($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        
        $this->lib->set_rules("billing",["trim","require"],true);
        $this->lib->set_rules("cost",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Merchant/Billing");
            exit;
        }
        $bill = [
            "billing"=> $this->lib->get_data("billing"),
            "cost"=> $this->lib->get_data("cost")
            ];
        $where = [
            "merchant" => $data["merchant"],
            "b_id"=>$data["billing_id"]
            ];
        if ($this->db->update("billing",$bill,$where) > 0) {
            Flasher::setFlash("success","Update success","Billing edited successfuly");
            $this->redirect("Merchant/Billing");
        }else {
            Flasher::setFlash("danger","Update failed","Billing failed to edit");
            $this->redirect("Merchant/Billing");
        }
    }
    public function deletebill($data){
        
        $where = [
            "merchant" => $data["merchant"],
            "b_id"=>$data["billing_id"]
            ];
        
        if ($this->db->Delete("billing",$where) > 0) {
            $w = [
            "m_id" => $data["merchant"],
            "b_id"=>$data["billing_id"],
            "status"=>0
            ];
            $this->db->Delete("transaction",$w);
            Flasher::setFlash("success","Delete success","Billing deleted successfuly");
            $this->redirect("Merchant/Billing");
        }else {
            Flasher::setFlash("danger","Update failed","Billing failed to delete");
            $this->redirect("Merchant/Billing");
        }
    }
    public function getusermerchant($id){
        $this->db->get_where("user",[
            "m_id"=>$id
            ]);
        return $this->db->row_array();
    }
    public function addusermerchant($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("email",["trim","require","email_valid","in_db" => "user/email/true"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Merchant/Merchantsettings");
            exit;
        }
        $email = $this->lib->get_data("email");
        $this->db->get_where("user",["email"=>$email]);
        $user = $this->db->row();
        if ($user["m_id"] > 0) {
            Flasher::setFlash("danger","Form validation error","The user has joined the merchant");
            $this->redirect("Merchant/Merchantsettings");
            exit;
        }
        if ($this->db->update("user",["m_id"=>$data["m_id"]],["email"=>$email]) > 0) {
            Flasher::setFlash("success","Update success","Add user merchant successfuly");
            $this->redirect("Merchant/Merchantsettings");
            exit;
        }else {
            Flasher::setFlash("danger","Update failed","User merchant failed to add");
            $this->redirect("Merchant/Merchantsettings");
            exit;
        }
    }
    public function deleteusermerchant($data){
        $email = $data["email"];
        if ($this->db->update("user",["m_id"=>0],["email"=>$email]) > 0) {
            Flasher::setFlash("success","Delete success","Delete user merchant successfuly");
            $this->redirect("Merchant/Merchantsettings");
            exit;
        }else {
            Flasher::setFlash("danger","Delete failed","User merchant failed to delete");
            $this->redirect("Merchant/Merchantsettings");
            exit;
        }
    }
    public function updatemerchant($data){
        
        $m_id = $data["m_id"];
        $merchant_id = $data["merchant_id"];
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        if ($m_id != $merchant_id) {
        $this->lib->set_rules("merchant_id",["trim","require","max"=>3,"min"=>3,"in_db" => "merchant/m_id/false"],true);
        }
        $this->lib->set_rules("merchant",["trim","require"],true);
        $this->lib->set_rules("bank_account",["trim","require"],true);
        
        if ($this->lib->run() == false) {
            $this->redirect("Merchant/Merchantsettings");
            exit;
        }
        $merchant_id = strtoupper($this->lib->get_data("merchant_id"));
        $merchant = $this->lib->get_data("merchant");
        $bank_account = $this->lib->get_data("bank_account");
        $this->db->get_where("merchant",["m_id" => $m_id]);
        $m = $this->db->row();
        $mer = [
            "m_id"=>$merchant_id,
            "merchant" => $merchant,
            "bank_id" =>$data["bank"],
            "bank_account"=>$bank_account
            ];
        $where = ["id"=>$m["id"]];
        
        if ($this->db->update("merchant",$mer,$where) > 0) {
            $this->db->query("UPDATE `billing` SET `merchant` = :m1 WHERE `merchant` = :m2");
            $this->db->bind("m1",$merchant_id);
            $this->db->bind("m2",$m_id);
            $this->db->execute();
            $this->db->query("UPDATE `transaction` SET `m_id` = :m1 WHERE `m_id` = :m2");
            $this->db->bind("m1",$merchant_id);
            $this->db->bind("m2",$m_id);
            $this->db->execute();
            Flasher::setFlash("success","Update success","Update merchant successfuly");
            $this->redirect("Merchant/Merchantsettings");
            exit;
        }else {
            Flasher::setFlash("danger","Update failed","Merchant failed to update");
            $this->redirect("Merchant/Merchantsettings");
            exit;
        }
        
    }
    private function transaction_id($l = 10){
        $permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
// Output: 54esmdr0qf 
return substr(str_shuffle($permitted_chars), 0, $l);
    }
    public function addtransaction($m,$b){
        $this->db->get_where("billing",["merchant"=>$m,"b_id"=>$b]);
        $bill = $this->db->row();
        $transaction_id = $this->transaction_id();
        if ($bill) {
            $order = $bill["merchant"];
            $order .= "-";
            $order .= $bill["b_id"];
            $order .= "-";
            $order .= $transaction_id;
            $cost1 = $bill["cost"];
            $cost2 = $bill["cost"]+$this->config->midtrans["fee"];
            $params = [
    'transaction_details' => [
        'order_id' => $order,
        'gross_amount' => $cost2
    ]
    //'customer_details' => [
        //'email' => ]
];
$this->library("Midtrans");
$this->lib->snap($params);
if ($this->lib->status != 200) {
    Flasher::setFlash("danger","Insert failed",$this->lib->message);
                $this->redirect("Merchant/Billing");
                exit;
}
$token = $this->lib->snapToken;

$where = [
    "m_id"=>$bill["merchant"],
    "b_id"=>$bill["b_id"],
    "transaction_id"=>$transaction_id,
    "title"=>"Transaction for ".$bill["billing"],
    "cost" => $cost1,
    "token"=> $token,
    "email" =>"",
    "status" =>0,
    "date_created" => time()
    ];
    if ($this->db->insert("transaction",$where)) {
        Flasher::setFlash("success","Insert success","Transaction added successfuly");
                $this->redirect("Merchant/");
                exit;
    }else{
    Flasher::setFlash("danger","Insert failed","Transaction failed to add");
                $this->redirect("Merchant/Billing");
                exit;
}
        }else{
            Flasher::setFlash("danger","Insert failed","Billing not found");
                $this->redirect("Merchant/Billing");
                exit;
        }
    }
    public function gettransaction($m){
        $this->db->get_where("transaction",["m_id"=>$m]);
        return $this->db->row_array();
        }
    
}