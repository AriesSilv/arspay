<?php
class User_model extends Model{
    public function getuser($email = null){
        if (is_null($email)) {
            $query = "SELECT `user`.*,`user_role`.`role` FROM `user` JOIN `user_role` ON `user`.`role_id` = `user_role`.`id`";
            $this->db->query($query);
            return $this->db->row_array();
        } else {
            $query = "SELECT `user`.*,`user_role`.`role` FROM `user` JOIN `user_role` ON `user`.`role_id` = `user_role`.`id` WHERE `email` = '$email'";
            
            $this->db->query($query);
            
            return $this->db->row();
        }
        
        
    }
    public function editprofile($data){
        $lib = $this->library("Form_Validation");
        $lib->set_data($data);
        $lib->set_rules("name",["trim","require"]);
        $lib->set_rules("phone",["trim","require","max" => 20]);
        if ($lib->run() == false) {
            $this->redirect("User/Editprofile");
            exit;
        }
        if ($_FILES["image"]["error"] == 4) {
            $img = $data["is_image"];
        }else{
            if ($data["is_image"] != "default.jpg") {
                unlink("img/profile/".$data["is_image"]);
            }
            $config = [
                "max_size" => 2048,
                "type" => ["jpg","jpeg","png","gif"],
                "path" => "img/profile/"
                ];
            $up = $this->library("Upload");
            $up->set("image",$config);
            if ($up->do_upload() == false) {
                $this->redirect("User/Editprofile");
                exit;
            }
            $img = $up->data("name");
        }
        $f = [
            "name" => $lib->get_data("name"),
            "phone" => $lib->get_data("phone"),
            "image" => $img 
            ];
        if ($this->db->update("user",$f,["email" => $data["email"]]) > 0) {
            Flasher::setFlash("success","Update Success","Edit profile successfully");
            $this->redirect("User/Editprofile");
        }else {
            Flasher::setFlash("danger","Update Failed","Profile failed to edit");
            $this->redirect("User/Editprofile");
        }
        
    }
    public function change_password($data,$url,$ch = null){
        $lib = $this->library("Form_Validation");
        $lib->set_data($data);
        if (!is_null($ch)) {
            $lib->set_rules("oldpassword",["trim","require","min"=>6,"password_verify"=>$ch["password"]],1);
        }
        
        $lib->set_rules("password",["trim","require","min"=>6,"matches"=>"repassword"],1);
        $lib->set_rules("repassword",["trim","require","min"=>6,"matches"=>"password"],1);
        if ($lib->run() == false) {
            $this->redirect($url);
            exit;
        }
        
        $password = $lib->get_data("password");
        
        $re = [
            "password" => password_hash($password,PASSWORD_DEFAULT)
            ];
        if ($this->db->update("user",$re,["email" => $data["email"]]) > 0) {
            Flasher::setFlash("success","Update Success","Change password successfully");
            $this->redirect($url);
        }else {
            Flasher::setFlash("danger","Update Failed","Password failed to change");
            $this->redirect($url);
        }
    }
}