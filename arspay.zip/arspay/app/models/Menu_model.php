<?php
class Menu_model extends Model{
    public function nav_menu($role){
        $query = "SELECT `user_menu`.`id`,`menu` FROM `user_menu` JOIN `user_access_menu` ON `user_menu`.`id` = `user_access_menu`.`menu_id` WHERE `user_access_menu`.`role_id` = :role ORDER BY `user_access_menu`.`menu_id` ASC";
        $this->db->query($query);
        $this->db->bind("role",$role);
        return $this->db->row_array();
    }
    public function nav_submenu($menu){
        $query = "SELECT * FROM `user_submenu` JOIN `user_menu` ON `user_submenu`.`menu_id` = `user_menu`.`id` WHERE `user_submenu`.`menu_id` = :menu AND `user_submenu`.`is_active` = 1";
     
        $this->db->query($query);
        $this->db->bind("menu",$menu);
        return $this->db->row_array();
    }
    public function getmenu(){
        $this->db->get("user_menu");
        
        return $this->db->row_array();
    }
    public function getsubmenu(){
        $query = "SELECT `user_submenu`.*,`user_menu`.`menu` FROM `user_submenu` JOIN `user_menu` ON `user_submenu`.`menu_id` = `user_menu`.`id` ORDER BY `user_menu`.`menu` ASC";
        $this->db->query($query);
        return $this->db->row_array();
    }
    public function insertmenu($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("menu",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Menu");
            exit;
        }
        $data = [
            "menu" => htmlspecialchars($this->lib->get_data("menu"))];
        if ($this->db->insert("user_menu",$data) > 0) {
            Flasher::setFlash("success","Insert Success","Menu added successfully");
            $this->redirect("Menu");
        }else{
            Flasher::setFlash("danger","Insert Failed","Menu failed to add");
            $this->redirect("Menu");
        }
    }
    public function updatemenu($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("menu",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Menu");
            exit;
        }
        $where = ["id"=>$data["id"]];
        $data = [
            "menu" => htmlspecialchars($this->lib->get_data("menu"))];
        if ($this->db->update("user_menu",$data,$where) > 0) {
            Flasher::setFlash("success","Update Success","Menu edited successfully");
            $this->redirect("Menu");
        }else{
            Flasher::setFlash("danger","Update Failed","Menu failed to edit");
            $this->redirect("Menu");
        }
    }
    public function deletemenu($data){
        
        $where = ["id"=>$data["id"]];
        
        if ($this->db->Delete("user_menu",$where) > 0) {
            Flasher::setFlash("success","Delete Success","Menu deleted successfully");
            $this->redirect("Menu");
        }else{
            Flasher::setFlash("danger","Delete Failed","Menu failed to delete");
            $this->redirect("Menu");
        }
    }
    
    public function insertsubmenu($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("submenu",["trim","require"],true);
        $this->lib->set_rules("url",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Menu/ManageSubmenu");
            exit;
        }
        if (intval($data["menu_id"]) < 1) {
           Flasher::setFlash("danger","Form validation error","Please select a menu");
            $this->redirect("Menu/ManageSubmenu");
            exit;
        }
        
        if (!isset($data["icon"])) {
            $data["icon"] = "fa-icons";
        }
        $data = [
            "menu_id" => $data["menu_id"],
            "submenu" => htmlspecialchars($this->lib->get_data("submenu")),
            "url" => $this->lib->get_data("url"),
            "icon" => $data["icon"],
            "is_active" => 1
            ];
        if ($this->db->insert("user_submenu",$data) > 0) {
            Flasher::setFlash("success","Insert Success","Submenu added successfully");
            $this->redirect("Menu/ManageSubmenu");
        }else{
            Flasher::setFlash("danger","Insert Failed","Submenu failed to add");
            $this->redirect("Menu/ManageSubmenu");
        }
    }
    public function updatesubmenu($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("submenu",["trim","require"],true);
        $this->lib->set_rules("url",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Menu/ManageSubmenu");
            exit;
        }
        if (intval($data["menu_id"]) < 1) {
           Flasher::setFlash("danger","Form validation error","Please select a menu");
            $this->redirect("Menu/ManageSubmenu");
            exit;
        }
        
        if (!isset($data["icon"])) {
            $data["icon"] = "fa-icons";
        }
        $where = ["id" => $data["id"]];
        $data = [
            "menu_id" => $data["menu_id"],
            "submenu" => htmlspecialchars($this->lib->get_data("submenu")),
            "url" => $this->lib->get_data("url"),
            "icon" => $data["icon"],
            ];
        if ($this->db->update("user_submenu",$data,$where) > 0) {
            Flasher::setFlash("success","Update Success","Submenu edited successfully");
            $this->redirect("Menu/ManageSubmenu");
        }else{
            Flasher::setFlash("danger","Update Failed","Submenu failed to edit");
            $this->redirect("Menu/ManageSubmenu");
        }
    }
    public function deletesubmenu($data){
        $where = ["id"=>$data["id"]];
        
        if ($this->db->Delete("user_submenu",$where) > 0) {
            Flasher::setFlash("success","Delete Success","Submenu deleted successfully");
            $this->redirect("Menu/ManageSubmenu");
        }else{
            Flasher::setFlash("danger","Delete Failed","Submenu failed to delete");
            $this->redirect("Menu/ManageSubmenu");
        }
    }
}