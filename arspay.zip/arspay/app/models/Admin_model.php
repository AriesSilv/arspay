<?php
class Admin_model extends Model{
    public function getrole(){
        $this->db->get("user_role");
        return $this->db->row_array();
    }
    public function insertrole($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("role",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Admin/Role");
            exit;
        }
        $data = [
            "is_default" => 0,
            "role" => htmlspecialchars($this->lib->get_data("role"))];
        if ($this->db->insert("user_role",$data) > 0) {
            Flasher::setFlash("success","Insert Success","Role added successfully");
            $this->redirect("Admin/Role");
        }else{
            Flasher::setFlash("danger","Insert Failed","Role failed to add");
            $this->redirect("Admin/Role");
        }
    }
    public function updaterole($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("role",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Admin/Role");
            exit;
        }
        $where = ["id"=>$data["id"]];
        $data = [
            "role" => htmlspecialchars($this->lib->get_data("role"))];
        if ($this->db->update("user_role",$data,$where) > 0) {
            Flasher::setFlash("success","Update Success","Role edited successfully");
            $this->redirect("Admin/Role");
        }else{
            Flasher::setFlash("danger","Update Failed","Role failed to edit");
            $this->redirect("Admin/Role");
        }
    }
    public function deleterole($data){
        $role = $data["role_id"];
        $id = $data["id"];
        if ($role < 1) {
            Flasher::setFlash("danger","Delete Failed","Point the user to another role");
            $this->redirect("Admin/Role");
            exit;
        }
        
        $where = ["id"=>$id];
        $query = "UPDATE `user` SET `role_id` = :a WHERE `role_id` = :b";
        $this->db->query($query);
        $this->db->bind("a",$role);
        $this->db->bind("b",$id);
        $is = $this->db->row_count();
        
        if ($this->db->Delete("user_role",$where) > 0) {
            Flasher::setFlash("success","Delete Success","Role deleted successfully");
            $this->redirect("Admin/Role");
        }else{
            Flasher::setFlash("danger","Delete Failed","Role failed to delete");
            $this->redirect("Admin/Role");
        }
    }

    public function insertuser($data){
        
        $lib = $this->library("Form_Validation");
        $lib->set_data($data);
        $lib->set_rules("name",["trim","require","min"=>3,"max"=> 20],true);
        $lib->set_rules("phone",["trim"],true);
        $lib->set_rules("email",["trim","require","email_valid","in_db" => "user/email/false"],true);
        $lib->set_rules("password",["trim","require","min" => 6],true);
        if ($lib->run() == false) {
            $this->redirect("Admin/Users");
            exit;
        }
        
        if ($data["role_id"] < 1) {
            $this->db->get_where("user_role",["is_default"=>1]);
            $rr = $this->db->row();
            $role = $rr["id"];
        } else {
            $role = $data["role_id"];
        }
        
        $name = htmlspecialchars($lib->get_data("name"));
        $email = htmlspecialchars($lib->get_data("email"));
        $phone = htmlspecialchars($lib->get_data("phone"));
        $pass = password_hash($lib->get_data("password"),PASSWORD_DEFAULT);
        $user_data = [
            "name" => $name,
            "email" => $email,
            "phone" => $phone,
            "image" => "default.jpg",
            "password" => $pass,
            "role_id" => $role,
            "m_id" => 0,
            "is_active" => 1,
            "date_created" => time()
            ];
        if ($this->db->insert("user",$user_data) > 0) {
            Flasher::setFlash("success","Insert Success","User added successfully");
            $this->redirect("Admin/Users");
        }else{
            Flasher::setFlash("danger","Insert Failed","User failed to add");
            $this->redirect("Admin/Users");
        }
    }
    
    public function updateuser($data){
        $lib = $this->library("Form_Validation");
        $lib->set_data($data);
        $this->db->get_where("user",["id"=>$data["id"]]);
        $user = $this->db->row();
        if ($user["email"] != $data["email"]) {
        $lib->set_rules("email",["trim","require","email_valid","in_db" => "user/email/false"],true);
        }
        $lib->set_rules("name",["trim","require","min"=>3,"max"=> 20],true);
        $lib->set_rules("phone",["trim"],true);
        
        
        if ($lib->run() == false) {
            $this->redirect("Admin/Users");
            exit;
        }
        

        $name = htmlspecialchars($lib->get_data("name"));
        $email = htmlspecialchars($lib->get_data("email"));
        $phone = htmlspecialchars($lib->get_data("phone"));
        $where = ["id"=>$data["id"]];
        $user_data = [
            "name" => $name,
            "email" => $email,
            "phone" => $phone,
            "role_id" => $data["role_id"]
            ];
        if ($this->db->update("user",$user_data,$where) > 0) {
            Flasher::setFlash("success","Update Success","User edited successfully");
            $this->redirect("Admin/Users");
        }else{
            Flasher::setFlash("danger","Update Failed","User failed to edit");
            $this->redirect("Admin/Users");
        }
    }
    public function deleteuser($data){
        
        $where = ["id"=>$data["id"]];
        $this->db->get_where("user",$where);
        $user = $this->db->row();
        if ($user["image"] != "default.jpg") {
            unlink("img/profile/".$user["image"]);
        }
        if ($this->db->Delete("user",$where) > 0) {
            Flasher::setFlash("success","Delete Success","User deleted successfully");
            $this->redirect("Admin/Users");
        }else{
            Flasher::setFlash("danger","Delete Failed","User failed to delete");
            $this->redirect("Admin/Users");
        }
    }
    public function getnotif(){
        $this->db->get("notif");
        return $this->db->row_array();
    }
    public function insertnotif($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("for",["trim"],true);
        $this->lib->set_rules("content",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Admin/Notifcenter");
            exit;
        }
        if (empty($data["for"])) {
            $for = "all";
        } else {
            $for = $this->lib->get_data("for");
        }
        if (!isset($data["icon"])) {
            $data["icon"] = "fa-bell";
        }
        $data = [
            "icon" => $data["icon"],
            "color" => $data["color"],
            "content" => htmlspecialchars($this->lib->get_data("content")),
            "notif_for" => $for,
            "date_created" => time()];
        if ($this->db->insert("notif",$data) > 0) {
            Flasher::setFlash("success","Insert Success","Notif added successfully");
            $this->redirect("Admin/Notifcenter");
        }else{
            Flasher::setFlash("danger","Insert Failed","Notif failed to add");
            $this->redirect("Admin/Notifcenter");
        }
    }
    public function updatenotif($data){
        $this->library("Form_Validation");
        $this->lib->set_data($data);
        $this->lib->set_rules("for",["trim"],true);
        $this->lib->set_rules("content",["trim","require"],true);
        if ($this->lib->run() == false) {
            $this->redirect("Admin/Notifcenter");
            exit;
        }
        
        if (empty($data["for"])) {
            $for = "all";
        } else {
            $for = $this->lib->get_data("for");
        }
        
        if (!isset($data["icon"])) {
            $data["icon"] = "fa-bell";
        }
        
        $notif = [
            "icon" => $data["icon"],
            "color" => $data["color"],
            "content" => htmlspecialchars($this->lib->get_data("content")),
            "notif_for" => $for];
        if ($this->db->update("notif",$notif,["id" => $data["id"]]) > 0) {
            Flasher::setFlash("success","Update Success","Notif edited successfully");
            $this->redirect("Admin/Notifcenter");
        }else{
            Flasher::setFlash("danger","Update Failed","Notif failed to edit");
            $this->redirect("Admin/Notifcenter");
        }
    }
    public function deletenotif($data){
        
        $where = ["id"=>$data["id"]];
        
        if ($this->db->Delete("notif",$where) > 0) {
            Flasher::setFlash("success","Delete Success","Notif deleted successfully");
            $this->redirect("Admin/Notifcenter");
        }else{
            Flasher::setFlash("danger","Delete Failed","Notif failed to delete");
            $this->redirect("Admin/Notifcenter");
        }
    }
}