<?php
class Vendor_model extends Model{
    public function getbyid($data){
        switch ($data["name"]) {
            case 'menu':
                $this->db->get_where("user_menu",["id" => $data["id"]]);
                
                break;
            case 'role':
                $this->db->get_where("user_role",["id" => $data["id"]]);
                
                break;
            case 'notif':
                $this->db->get_where("notif",["id" => $data["id"]]);
                
            break;
            case 'usermerchant':
                $this->db->get_where("user",["email" => $data["id"]]);
                
            break;
            case 'billing':
                $this->db->get_where("billing",["b_id" => $data["id"]]);
                
            break;
            case 'reset_password':
                $this->db->get_where("user",["id" => $data["id"]]);
                
            break;
            case 'merchantcogs':
            $this->db->get_where("merchant",["m_id" => $data["id"]]);
            break;
            case 'submenu':
                $query = "SELECT `user_submenu`.*,`user_menu`.`menu` FROM `user_submenu` JOIN `user_menu` ON `user_submenu`.`menu_id` = `user_menu`.`id` WHERE `user_submenu`.`id` = :id";
                $this->db->query($query);
                $this->db->bind("id",$data["id"]);
                
                break;
                case 'users':
                $query = "SELECT `user`.*,`user_role`.`role` FROM `user` JOIN `user_role` ON `user`.`role_id` = `user_role`.`id` WHERE `user`.`id` = :id";
                $this->db->query($query);
                $this->db->bind("id",$data["id"]);
                
                break;
            default:
                return false;
                break;
        }
        return $this->db->row();
    }
    public function search_icon($keyword){
        $dbi = new Database("vendor");
        $query = "SELECT * FROM `icons` WHERE `label` LIKE :label OR `icon`LIKE :icon";
        $dbi->query($query);
        $dbi->bind("label","%$keyword%");
        $dbi->bind("icon","%$keyword%");
        return $dbi->row_array();
    }
    public function check_access($m,$r){
        $this->db->get_where("user_access_menu",["menu_id" => $m,"role_id" => $r]);
        if ($this->db->row_count() > 0) {
            return "checked";
        }
    }
    public function active($active){
        
        if ($active > 0) {
            return "checked";
        }
    }
    public function nav_notif($email){
        $query = "SELECT * FROM `notif` WHERE `notif_for` = :all OR `notif_for` = :email";
        $this->db->query($query);
        $this->db->bind("all","all");
        $this->db->bind("email",$email);
        return $this->db->row_array();
        
        
    }
    public function send_otp($data){
        $email = $data["email"];
        $primary = $data["email_primary"];
        $otp = $data["otp"];
        $user_token = [
            "email" => $email,
            "token" => $otp,
            "date_created" => time()
        ];
        if ($this->db->insert("user_token",$user_token) > 0) {
            $arr = [
                "email"=>$email,
                "otp" => $otp,
                "primary" => $primary
                ];
            
  return json_encode($arr);
        }
    }
    public function gettransaction($id){
        $where = ["transaction_id"=>$id];
        $this->db->get_where("transaction",$where);
        return $this->db->row();
    }
    
}