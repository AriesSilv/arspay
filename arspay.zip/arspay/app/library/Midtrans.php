<?php
class Midtrans extends Library{
    private $midtrans;
    public $status;
    public $message;
    public $snapToken;
    public function __construct(){
        $cog = new Config;
        $this->midtrans = $cog->midtrans;
    }
    public function snap($params){
//$params = ['transaction_details' => ['order_id' => rand(),'gross_amount' => 5000,]'customer_details' => [
        //'email' => ]];
$params = base64_encode(json_encode($params));
$this->midtrans["url"] .= "xhr.php?key=".$this->midtrans["key"];
$this->midtrans["url"] .= "&params=".$params;
$arrContextOptions=array(
    "ssl"=>array(
        "verify_peer"=>false,
        "verify_peer_name"=>false,
    ),
);  
$data = file_get_contents($this->midtrans["url"],false,stream_context_create($arrContextOptions));


$token = json_decode($data,1);
$this->status = $token["status"];
$this->message = $token["message"];
$this->snapToken = $token["data"];
    }
}