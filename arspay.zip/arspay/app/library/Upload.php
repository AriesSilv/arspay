<?php
class Upload{
    private $data;
    private $do = [];
    private $message;
    private $flash;
    public function set($name,$config,$err = null){
        $this->flash = $err;
        $file = $_FILES[$name];
        if(in_array("require",$config) OR $config["require"] == true){
            if ($file["error"] == 4) {
                if (is_null($err)) {
                    $this->do[] = false;
                    Flasher::setForm_error($name,$name." file is require");
                    return false;
                    exit;
                }else {
                    $this->do[] = false;
                    $this->message = $name." file is require";
                    return false;
                    exit;
                }
            }
        }
        $ex = $file["name"];
            $ex = strtolower(end(explode(".",$ex)));
            
        if (isset($config["type"])) {
            
            if (!in_array($ex,$config["type"])) {
                if (is_null($err)) {
                    $this->do[] = false;
                    Flasher::setForm_error($name,"Files not allowed");
                    return false;
                    exit;
                }else {
                    $this->do[] = false;
                    $this->message = "files not allowed";
                    return false;
                    exit;
                }
            }
        }
        
        if (isset($config["max_size"]) AND !empty($config["max_size"])) {
            $size = ceil(intval($file["size"]) / 1024);
            $size = intval($size);
            
            if ($size > $config["max_size"]) {
                if (is_null($err)) {
                    $this->do[] = false;
                    Flasher::setForm_error($name," size is too large");
                    return false;
                    exit;
                }else {
                    $this->do[] = false;
                    $this->message = $name." size is too large";
                    return false;
                    exit;
                }
            }
        }
        $this->do[] = true;
        $file["name"] = uniqid().".".$ex;
        $this->data = $file;
        move_uploaded_file($file["tmp_name"],$config["path"].$file["name"]);
        return true;
    }
    public function data($name){
        return $this->data[$name];
    }
    public function do_upload(){
        if (in_array(false,$this->do)) {
            if (count($this->message) > 1 AND $this->flash == true) {
                Flasher::setFlash("danger","File upload error",$this->message);
            }else if(count($this->message) < 2 AND $this->flash == true){
                Flasher::setFlash("danger","File upload error",$this->message[0]);
            }
            return false;
        }else {
            unset($_SESSION["form_error"]);
            return true;
        }
    }
}