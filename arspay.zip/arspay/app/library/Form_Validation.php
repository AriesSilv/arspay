<?php
class Form_Validation extends Library{
    private $data;
    private $run = [];
    private $message = [];
    private $flash;
    public function set_data($data){
        $this->data = $data;
    }
    public function set_rules($name, $preset = [],$err = null){
        $this->flash = $err;
        $setdata = $this->data[$name];
        
        if (in_array("trim",$preset)) {
            $setdata = trim($setdata);
            
        }
        if (in_array("require",$preset)) {
            
                if ($setdata == "") {
                 $this->run[] = false;
                 if (is_null($err)) {
                    Flasher::setForm_error($name,$name." field is require",$this->data);
                                        
                   
                 }elseif($err == true) {
                     $this->message[] = $name." field is require";

                 }
                 return false;
                    exit;
                }
        }
        
        if (isset($preset["password_verify"])) {
                if (password_verify($setdata,$preset["password_verify"]) == false) {
                 $this->run[] = false;
                 if (is_null($err)) {
                    Flasher::setForm_error($name,$name." is wrong",$this->data);
                 }else {
                     $this->message[] = $name." is wrong";
                    
                 }
                    
                   return false;
                    exit;
                }
            
        }
        if (isset($preset["min"])) {
            if (strlen($setdata) < intval($preset["min"])) {
                
                $this->run[] = false;
                if (is_null($err)) {
                    Flasher::setForm_error($name,$name." field is too short",$this->data);
                 }else {
                     $this->message[] = $name." is too short";
                    
                 }
                
                return false;
                    exit;
                
            }
        }
        
        if (isset($preset["max"])) {
            if (strlen($setdata) > intval($preset["max"])) {
                
                $this->run[] = false;
                if (is_null($err)) {
                    Flasher::setForm_error($name,$name." field is too long",$this->data);
                 }else {
                     $this->message[] = $name." is too long";
                    
                 }
                return false;
                    exit;
            }
        }
        if (isset($preset["matches"])) {
            if ($setdata != $this->data[$preset["matches"]]) {
                $this->run[] = false;
                if (is_null($err)) {
                    Flasher::setForm_error($name,$name." and ".$preset["matches"]." dont matches",$this->data);
                 }else {
                     $this->message[] = $name." and ".$preset["matches"]." dont matches";
                    
                 }
                
                return false;
                    exit;
            }
        }
        if (in_array("email_valid",$preset)) {
            
                if (!preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/",$setdata)) {
                    
                    $this->run[] = false;
                    if (is_null($err)) {
                    Flasher::setForm_error($name,$name." field dont match email format",$this->data);
                 }else {
                     $this->message[] = $name." field dont match email format";
                    
                 }
                    
                    return false;                    exit;
                }
            
        }
        if (in_array("url_valid",$preset)) {
            
                if (!preg_match("^(ht|f)tp(s?)\:\/\/[0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*(:(0-9)*)*(\/?)([a-zA-Z0-9\-\.\?\,\'\/\\\+&amp;%\$#_]*)?$",$setdata)) {
                    
                    $this->run[] = false;
                    if (is_null($err)) {
                    Flasher::setForm_error($name,$name." field dont match url format",$this->data);
                 }else {
                     $this->message[] = $name." field dont match url format";
                    
                 }
                    return false;
                    exit;
                }
            
        }
        if (isset($preset["in_db"])) {
            if (!empty($preset['in_db'])) {
                $dbd = explode("/",$preset["in_db"]);
                $tbl = $dbd[0];
                $row = $dbd[1];
                $ck = $dbd[2];
                $q = "SELECT `".$row."` FROM `".$tbl."` WHERE `".$row."` = :d";
                if ($ck == "true") {
                    $this->db->query($q);
                    $this->db->bind("d",$this->data[$name]);
                    if (count($this->db->row_array()) < 1) {
                        $this->run[] = false;
                        if (is_null($err)) {
Flasher::setForm_error($name,$name." not exists",$this->data);
                 }else {
                     $this->message[] = $name." not exists"; 
                    
                 }
                        
                        return false;
                        exit;
                        
                    }
                }elseif ($ck == "false") {
                    $this->db->query($q);
                    $this->db->bind("d",$this->data[$name]);
                    if (count($this->db->row_array()) > 0) {
                        $this->run[] = false;
                        if (is_null($err)) {
Flasher::setForm_error($name,$name." already exists",$this->data);
                 }else {
                     $this->message[] = $name." already exists"; 
                    
                    
                 }
                        return false;
                        exit;
                        
                    }
                }
            }
        }
        
        $this->run[] = true;
        $this->data[$name] = $setdata;
        
        return true;
    }
    public function get_data($name){
        return $this->data[$name];
    }
    public function run(){
        if (in_array(false,$this->run)) {
            if (count($this->message) > 1 AND $this->flash == true) {
                Flasher::setFlash("danger","Form validation error",$this->message);
            }else if(count($this->message) < 2 AND $this->flash == true){
                Flasher::setFlash("danger","Form validation error",$this->message[0]);
            }
            return false;
        }else {
            unset($_SESSION["form_error"]);
            return true;
        }
    }
    
    
}