<?php
class Mail extends Library{
    private $host = "smtp.elasticemail.com";
    private $username = "noreplay.ariessilver@gmail.com";
    private $password = "D4336770BFA1F374824F015B119C8C2E75FF";
    private $secure = "ab232c76-6ade-4db5-b6d0-df3f19b22709";
    public $to;
    private $from = "noreplay.ariessilver@gmail.com";
    public $subject;
    public $body;
    public $head;
    public $reddir;

    public function card($card = null){
        if (is_null($card)) {
                return '<div class="card" style="width: 90%;
 margin: 20px auto;
 background-color: #F8FBFE;
 border-radius: 8px;
 z-index: 1;
 font-size: 10px;
 text-align: center;
 padding: 10px 10px;
 border: 1px solid #eaeaea;">
  <header style="margin-bottom: 1rem;">
    '.$this->head.'
  </header>
  <hr>
  <div class="card__content" style="margin-bottom: 1rem;">
'.$this->body.'
  </div>
  <hr>
  <footer>
      <span>Copyright &copy; Arspay 2023</span>
  </footer>
</div>';
        } else {
            return $card;
        }
        
    }
    public function send($config = null){
        if (is_null($config)) {
            echo '
            <script>
            var Email = { send: function (a) { return new Promise(function (n, e) { a.nocache = Math.floor(1e6 * Math.random() + 1), a.Action = "Send"; var t = JSON.stringify(a); Email.ajaxPost("https://smtpjs.com/v3/smtpjs.aspx?", t, function (e) { n(e) }) }) }, ajaxPost: function (e, n, t) { var a = Email.createCORSRequest("POST", e); a.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), a.onload = function () { var e = a.responseText; null != t && t(e) }, a.send(n) }, ajax: function (e, n) { var t = Email.createCORSRequest("GET", e); t.onload = function () { var e = t.responseText; null != n && n(e) }, t.send() }, createCORSRequest: function (e, n) { var t = new XMLHttpRequest; return "withCredentials" in t ? t.open(e, n, !0) : "undefined" != typeof XDomainRequest ? (t = new XDomainRequest).open(e, n) : t = null, t } };
Email.send({
    SecureToken : "'.$this->secure.'",
    Host : "'.$this->host.'",
    Username : "'.$this->username.'",
    Password : "'.$this->password.'",
    To : "'.$this->to.'",
    From : "'.$this->from.'",
    Subject : "'.$this->subject.'",
    Body : `'.$this->card().'`
}).then(function(message){
  window.location.href = "'.$this->reddir.'";
});
        </script>
            ';
        
        } else {
            echo '
            <script>
            Email.send({
    SecureToken : '.$this->secure.',
    Host : '.$this->host.',
    Username : '.$this->username.',
    Password : '.$this->password.',
    To : '.$config["to"].',
    From : '.$this->from.',
    Subject '.$config["subject"].',
    Body : '.$config["body"].'
}).then(
  message => console.log(message);
  
);
            </script>';
            
        }
        
    }
}