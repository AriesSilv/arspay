<?php
class Flasher{
    public static function setFlash($type,$action,$message){
        $_SESSION["flash"] = [
            "type" => $type,
            "action" => $action,
            "message" => $message,
            ];
    }
    public static function flash_message(){
        if (isset($_SESSION["flash"])) {
            $s = $_SESSION["flash"];
            if (is_array($s["message"])) {
                $of = count($s["message"]);
            } else {
                $of = 0;
            }
            
            if ($of > 0) {
                for ($i = 0; $i < $of; $i++) {
                     echo '
<div class="alert alert-'.$s["type"].' alert-dismissible fade show" role="alert">
  <strong>'.$s["action"].'</strong> '.$s["message"][$i].'

</div>';
                }
            } else {
                echo '
<div class="alert alert-'.$s["type"].' alert-dismissible fade show" role="alert">
  <strong>'.$s["action"].'</strong> '.$s["message"].'

</div>';
            }
            
                          
            unset($_SESSION["flash"]);
        }
    }
    public static function setForm_error($name,$message,$value = null){
        
        $_SESSION["form_error"][$name] = ["message"=>$message];
        $_SESSION["form_error"]["value"] = $value;
    }
    public static function form_value($name){
        if (isset($_SESSION["form_error"])) {
return $_SESSION["form_error"]["value"][$name];
        }
        
    }
    public static function form_error($name){
        if (isset($_SESSION["form_error"][$name])) {
return $_SESSION["form_error"][$name]["message"];
        }
        
        
    }
}