<?php
class Database{
    private $host;
    private $user;
    private $pass;
    private $db_name;
    
    private $dbh;
    private $stmt;
    
    public function __construct($db = null){
        $config = new Config;
        $this->host = $config->DB_HOST;
        $this->user = $config->DB_USER;
        $this->pass = $config->DB_PASS;
        if (is_null($db)) {
            $this->db_name = $config->DB_NAME;
            
        }else {
            $this->db_name = $db;
        }
        
        
        $dsn = "mysql:host=".$this->host.";dbname=".$this->db_name;
        $option = [
            PDO::ATTR_PERSISTENT =>true,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ];
        
        try {
            $this->dbh = new PDO($dsn,$this->user,$this->pass,$option);
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    public function query($query){
        $this->stmt = $this->dbh->prepare($query);
    }
    public function bind($param,$value,$type = null){
        if (is_null($type)) {
            switch (true) {
                case is_int($value):
                    $type = PDO::PARAM_INT;
                    break;
                case is_bool($value):
                    $type = PDO::PARAM_BOOL;
                    break;
                case is_null($value):
                    $type = PDO::PARAM_NULL;
                    break;
                default:
                    $type = PDO::PARAM_STR;
                    break;
            }
        }
        $this->stmt->bindValue($param,$value,$type);
    }
    public function execute(){
        $this->stmt->execute();
    }
    public function row_array(){
        $this->execute();
        return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public function row(){
        $this->execute();
        return $this->stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function row_count(){
        $this->execute();
        return $this->stmt->rowCount();
    }
    public function get($tbl,$field = null){
        if (is_null($field)){
        $query = "SELECT * FROM `$tbl`";
        $this->query($query);
            
        }
    }
    public function insert($tbl,$data){
        $query = "INSERT INTO `".$tbl."` (";
        foreach($data as $x=>$val){
                 if ($x === array_key_last($data)) {
                    $b = "`".$x."`";
                } else {
                    $b = "`".$x."` ,";
                }
                $query .= $b;
            }
        $query .= ") VALUES (";
            foreach($data as $x=>$val){
                
                if ($x === array_key_last($data)) {
                    $b = ":".$x;
                } else {
                    $b = ":".$x.", ";
                }
                
                $query .= $b;
            }
        $query .= ")";
        
        $this->query($query);
        
        foreach ($data as $x => $val){
            $this->bind($x,$val);
        }
        
        return $this->row_count();
    }
    public function update($tbl,$data,$where,$a = null){
        $query = "UPDATE `$tbl` SET ";
        if (is_null($a) OR $a == "AND") {
            foreach($data as $x=>$val){
                    if ($x === array_key_last($data)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                    $b = "`".$x."` = :".$x.",";
                    }
                    $query .= $b;
            }
            $query .= " WHERE ";
            foreach($where as $x=>$val){
                    if ($x === array_key_last($where)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                    $b = "`".$x."` = :".$x." &&";
                    }
                    $query .= $b;
            }
        }elseif ($a == "OR"){
            foreach($data as $x=>$val){
                    if ($x === array_key_last($data)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                    $b = "`".$x."` = :".$x.",";
                    }
                    $query .= $b;
            }
            $query .= " WHERE ";
            foreach($where as $x=>$val){
                    if ($x === array_key_last($where)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                    $b = "`".$x."` = :".$x." ||";
                    }
                    $query .= $b;
            }
        }
        
        $this->query($query);
            foreach ($data as $x => $val){
                $this->bind($x,$val);
            }
            foreach ($where as $x => $val){
                $this->bind($x,$val);
            }
            return $this->row_count();
        
    }
    public function Delete($tbl,$data,$a = null){
        $query = "DELETE FROM `$tbl` WHERE ";
        if (is_null($a) OR $a == "AND") {
            foreach($data as $x=>$val){
                    if ($x === array_key_last($data)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                    $b = "`".$x."` = :".$x." &&";
                    }
                    $query .= $b;
            }
            
        }elseif($a == "OR"){
            foreach($data as $x=>$val){
                    if ($x === array_key_last($data)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                    $b = "`".$x."` = :".$x." ||";
                    }
                    $query .= $b;
            }
        }
        $this->query($query);
        foreach($data as $x=>$val){
            $this->bind($x,$val);
        }
        return $this->row_count();
    }
    public function get_where($tbl,$data = [],$a = null,$f = null){
        if (is_null($f)) {
            $query = "SELECT * FROM `".$tbl."` WHERE ";
            if (is_null($a)) {
                foreach($data as $x=>$val){
                    if ($x === array_key_last($data)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                    $b = "`".$x."` = :".$x." &&";
                    }
                    $query .= $b;
                }
                
            }else {
                foreach($data as $x=>$val){
                    if ($x === array_key_last($data)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                        $b = "`".$x."` = :".$x." ||";
                    }
                    $query .= $b;
                }
                    
            }
            
            $this->query($query);
            foreach ($data as $x => $val){
                $this->bind($x,$val);
            }
        }else{
            $query = "SELECT `".$f."` FROM `".$tbl."` WHERE ";
            if (is_null($a) OR $a == "AND") {
                foreach($data as $x=>$val){
                    if ($x === array_key_last($data)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                    $b = "`".$x."` = :".$x." &&";
                    }
                    $query .= $b;
                }
                
            }elseif($a == "OR") {
                foreach($data as $x=>$val){
                    if ($x === array_key_last($data)) {
                        $b = "`".$x."` = :".$x;
                    } else {
                        $b = "`".$x."` = :".$x." ||";
                    }
                    $query .= $b;
                }
                    
            }
            
            $this->query($query);
            foreach ($data as $x => $val){
                $this->bind($x,$val);
            }
        }
    }
}