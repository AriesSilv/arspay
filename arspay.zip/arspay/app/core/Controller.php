<?php
class Controller{
    public $config;
    private $base_url;
    public $db;
    public $lib;
    protected $userdata;
    public function view($view,$data = []){
        require_once("../app/views/".$view.".php");
    }
    public function base_url($url){
        return $this->base_url.$url;
    }
    protected function model($model){
        require_once("../app/models/".$model.".php");
        return new $model;
    }
    public function library($lib){
        require_once("../app/library/".$lib.".php");
        $this->lib = new $lib;
        return new $lib;
    }
    public function redirect($l,$b = null){
        if (is_null($b)) {
            echo "<script>window.location.href = '".$this->base_url.$l."';</script>";
        }
    }
    public function userlog(){
        if (isset($_SESSION["user"])) {
        $user = $this->model("User_model")->getuser($_SESSION["user"]["email"]);
        $this->userdata = $user;
        }
    }
    public function __construct(){
        $conf = new Config;
        $this->config = $conf;
        $this->base_url = $conf->BASE_URL;
        $this->db = new Database;
        $this->userlog();
        
    }
    protected function is_loggin(){
        $url = $_GET["url"];
        $url = explode("/",$url);
        $url = $url[0];
        
        if (!isset($_SESSION["user"])) {
            $this->redirect("Auth");
            exit;
        }
        
            $role = $this->userdata["role_id"];
            $where = ["menu" => $url];
            $this->db->get_where("user_menu",$where);
            $querymenu = $this->db->row();
            $menu_id = $querymenu["id"];
            
            $this->db->get_where("user_access_menu",[
                "role_id" => $role,
                "menu_id" => $menu_id
            ]);
            if ($this->db->row_count() < 1) {
                $this->redirect("Auth/Blocked");
            }
            
            
        
        
    }
    protected function is_menu(){
        $url = $_GET["url"];
        $url = explode("/",$url);
        if (isset($url[1])) {
            $uri = $url[0]."/".$url[1];
        }else {
            $uri = $url[0];
        }
        
        $this->db->get_where("user_submenu",["url" => $uri]);
        $sm = $this->db->row();
        if ($sm) {
            if ($sm["is_active"] < 1) {
            $this->redirect("Auth/Notfound");
            }
        }
        
        
        
    }
    
    
}