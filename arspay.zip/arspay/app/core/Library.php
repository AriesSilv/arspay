<?php
class Library{
    public $config;
    private $base_url;
    public $db;
    public $lib;
    
    public function base_url($url = ""){
        return $this->base_url.$url;
    }
    public function model($model){
        require_once("../app/models/".$model.".php");
        return new $model;
    }
    public function library($lib){
        require_once("../app/library/".$lib.".php");
        $this->lib = new $lib;
        return new $lib;
    }
    public function redirect($l,$b = null){
        if (is_null($b)) {
            echo "<script>window.location.href = '".$this->base_url.$l."';</script>";
        }
    }
    public function __construct(){
        $conf = new Config;
        $this->config = $conf;
        $this->base_url = $conf->BASE_URL;
        $this->db = new Database;
    }
}