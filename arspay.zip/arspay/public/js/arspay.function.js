const config = {mail:{
    SecureToken : 'ab232c76-6ade-4db5-b6d0-df3f19b22709',
    Host : 'smtp.elasticemail.com',
    Username : 'noreplay.ariessilver@gmail.com',
    Password : 'D4336770BFA1F374824F015B119C8C2E75FF'
    
}};

function addDataModal(data){
    const uri = $("body").attr("data-url");
    const url = $("body").attr("data-url")+"Vendor/get_data";
    $("#DataModal .modal-footer .trigger").html("Add");
    $("#DataModal .modal-footer .trigger").attr("class","trigger btn btn-primary");
    $("#DataModal .modal-footer .trigger").attr("name","add");
    
    switch (data.attr("data-temp")) {
        case 'menu':
            $("#DataModal .modal-title").html("New Menu");
            var temp = `
                <div class="form-group">
                <label for="menu" class="form-label">Menu</label>
                <input type="text" id="menu" name="menu" class="form-control">
                </div>`;
            $("#DataModal .modal-body").html(temp);
        break;
        case 'role':
            $("#DataModal .modal-title").html("New Role");
            var temp = `
                <div class="form-group">
                <label for="role" class="form-label">Role</label>
                <input type="text" id="role" name="role" class="form-control">
                </div>`;
            $("#DataModal .modal-body").html(temp);
        break;
        case 'notif':
            $("#DataModal .modal-title").html("New Notification");
            var temp = `
                <div class="form-group">
                <label for="for" class="form-label">Notif For</label>
                <input type="text" id="for" name="for" class="form-control">
                </div>
                <div class="form-group">
                <label for="content" class="form-label">Content</label>
        <textarea class="form-control" name="content" id="content"></textarea>
                </div>
            <div class="form-group">
                <label for="color" class="form-label">Background</label>
                <input type="color" id="color" value="#0d6efd" name="color" class="form-control">
                </div>
            <div class="form-group">
                <label for="icon" class="form-label">Icon</label>
                <input type="text" id="icon" class="form-control input-icon-search" onkeyup="search_icon($(this))">
                <div class="mt-2 icon-body overflow-auto"></div>
                </div>
                `;
                
            $("#DataModal .modal-body").html(temp);
        break;
        case 'submenu':
            $("#DataModal .modal-title").html("New Submenu");
            send_ajax(url,{get:"user_menu"},function(menu){
                     let temp = `
                    <div class="form-group">
                    <label for="menu" class="form-label">Menu</label>
                    <select class="form-control" name="menu_id" id="menu">
                    <option value="0" selected>Open this select menu</option>`;
                    for(var i = 0;i < menu.length;i++){
                     temp += `<option value="`+menu[i].id+`">`+menu[i].menu+`</option>`;
                     
                    }
                temp += `
                </select>
                </div>
                <div class="form-group">
                <label for="submenu" class="form-label">Submenu</label>
                <input type="text" id="submenu" name="submenu" class="form-control">
                </div>
                <div class="form-group">
  <label for="url" class="form-label">URL</label>
  <div class="input-group">
    <span class="input-group-text" id="basic-addon3">`+uri+`</span>
    <input type="text" class="form-control" id="url" name="url">
  </div>
</div>
                <div class="form-group">
                <label for="icon" class="form-label">Icon</label>
                <input type="text" id="icon" class="form-control input-icon-search" onkeyup="search_icon($(this))">
                <div class="mt-2 icon-body overflow-auto"></div>
                </div>`;
            $("#DataModal .modal-body").html(temp);
            
                

                
                    
                    


                },false);

            
        break;
        case 'users':
            $("#DataModal .modal-title").html("New User");
            send_ajax(url,{get:"user_role"},function(role){
                     let temp = `
                    <div class="form-group">
                    <label for="role" class="form-label">Role</label>
                    <select class="form-control" name="role_id" id="role">
                    <option value="0" selected>Open this select role</option>`;
                    for(var i = 0;i < role.length;i++){
                     temp += `<option value="`+role[i].id+`">`+role[i].role+`</option>`;
                     
                    }
                temp += `
                </select>
                </div>
                <div class="form-group">
                <label for="email" class="form-label">Email</label>
                <input type="email" id="email" name="email" class="form-control">
                </div>
                <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input type="password" id="password" name="password" class="form-control">
                </div>
                <div class="form-group">
                <label for="name" class="form-label">Name</label>
                <input type="text" id="name" name="name" class="form-control">
                </div>
                <div class="form-group">
                <label for="phone" class="form-label">Phone</label>
                <input type="tel" id="phone" name="phone" class="form-control">
                </div>

`;
            $("#DataModal .modal-body").html(temp);
            
                

                
                    
                    


                },false);

            
        break;
        case 'billing':
            var m = data.attr("data-merchant");
            $("#DataModal .modal-title").html("New Billing");
            var temp = `
                <div class="form-group">
                <label for="billing_id" class="form-label">Billing ID</label>
                <input type="hidden" name="merchant" value="`+m+`" class="form-control">
                <input type="text" id="billing_id" name="billing_id" class="form-control">
                </div>
                <div class="form-group">
                <label for="billing" class="form-label">Billing</label>
                <input type="text" id="billing" name="billing" class="form-control">
                </div>
                <div class="form-group">
                <label for="cost" class="form-label">Cost</label>
                <input type="tel" id="cost" name="cost" class="form-control">
                </div>
                `;
            $("#DataModal .modal-body").html(temp);
        break;
        case 'usermerchant':
            const m_id = data.attr("m-id");
            $("#DataModal .modal-title").html("Add User Mechant");
            var temp = `
                <div class="form-group">
                <label for="email" class="form-label">Email</label>
                <input type="hidden" name="m_id" class="form-control" value="`+m_id+`">
                <input type="email" id="email" name="email" class="form-control">
                </div>`;
            $("#DataModal .modal-body").html(temp);
        break;
        
        
    }
}
function editDataModal(data){
    const uri = $("body").attr("data-url");
    const url = $("body").attr("data-url")+"Vendor/get_data";
    $("#DataModal .modal-footer .trigger").html("Edit");
    $("#DataModal .modal-footer .trigger").attr("class","trigger btn btn-info");
    $("#DataModal .modal-footer .trigger").attr("name","edit");
    switch (data.attr("data-temp")) {
        case 'menu':
            $("#DataModal .modal-title").html("Edit Menu");
            getdatabyid("Vendor/getbyid",data,function(data){
            let temp = `
                <div class="form-group">
                <label for="menu" class="form-label">Menu</label>
                <input type="hidden" id="id" name="id" class="form-control" value="`+data.id+`">
                <input type="text" id="menu" name="menu" class="form-control" value="`+data.menu+`">
                </div>`;
            $("#DataModal .modal-body").html(temp);
            });
        break;
        case 'role':
            $("#DataModal .modal-title").html("Edit Role");
            getdatabyid("Vendor/getbyid",data,function(data){
            let temp = `
                <div class="form-group">
                <label for="role" class="form-label">Role</label>
                <input type="hidden" id="id" name="id" class="form-control" value="`+data.id+`">
                <input type="text" id="menu" name="role" class="form-control" value="`+data.role+`">
                </div>`;
            $("#DataModal .modal-body").html(temp);
            });
        break;
        case 'billing':
            const merchant = data.attr("data-merchant");
            $("#DataModal .modal-title").html("Edit Billing");
            getdatabyid("Vendor/getbyid",data,function(bill){
            let temp = `
                <div class="form-group">
                <label for="billing_id" class="form-label">Billing ID</label>
                <input type="hidden" name="merchant" value="`+merchant+`" class="form-control">
                <input type="text" id="billing_id" name="billing_id" class="form-control" value="`+bill.b_id+`" readonly>
                </div>
                <div class="form-group">
                <label for="billing" class="form-label">Billing</label>
                <input type="text" id="billing" name="billing" class="form-control" value="`+bill.billing+`">
                </div>
                <div class="form-group">
                <label for="cost" class="form-label">Cost</label>
                <input type="tel" id="cost" name="cost" class="form-control" value="`+bill.cost+`">
                </div>
                `;
            $("#DataModal .modal-body").html(temp);
            });
        break;
        case 'notif':
            $("#DataModal .modal-title").html("Edit Notification");
            getdatabyid("Vendor/getbyid",data,function(data){
            let temp = `
                <div class="form-group">
                <input type="hidden" id="id" name="id" class="form-control" value="`+data.id+`">
                <label for="for" class="form-label">Notif For</label>
                <input type="text" id="for" name="for" class="form-control" value="`+data.notif_for+`">
                </div>
                <div class="form-group">
                <label for="content" class="form-label">Content</label>
                <textarea class="form-control" name="content" id="content">`+data.content+`</textarea>
                </div>
            <div class="form-group">
                <label for="color" class="form-label">Background</label>
                <input type="color" id="color" name="color" class="form-control" value="`+data.color+`">
                </div>
                <div class="form-group">
                <label for="icon" class="form-label">Icon</label>
                <input type="text" id="icon" class="form-control input-icon-search" onkeyup="search_icon($(this))">
                <div class="mt-2 icon-body overflow-auto">
                <table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Icon</th>

            <th>Class</th>
        </tr>
    </thead>
    <tbody>
<tr>
            <td>
                <div class="form-check">
  <input class="form-check-input" type="radio" name="icon" id="icon" value="`+data.icon+`" checked>
</div>
            </td>
            <td><i class="fa-solid fa-fw `+data.icon+`"></i></td>
            <td>`+data.icon+`</td>
        </tr>
    </tbody>
    </table>
                </div>
                </div>
                `;
            $("#DataModal .modal-body").html(temp);
            });
        break;
        case 'submenu':
            $("#DataModal .modal-title").html("Edit Submenu");
            send_ajax(url,{get:"user_menu"},function(menu){
                const menues = menu;
                getdatabyid("Vendor/getbyid",data,function(data){
                  
                     let temp = `
                    <div class="form-group">
                <input type="hidden" id="id" name="id" class="form-control" value="`+data.id+`">
                    <label for="menu" class="form-label">Menu</label>
                    <select class="form-control" name="menu_id" id="menu">
                    <option value="`+data.menu_id+`" selected>Menu : `+data.menu+`</option>`;
                    for(var i = 0;i < menues.length;i++){
                     temp += `<option value="`+menues[i].id+`">`+menues[i].menu+`</option>`;
                     
                    }
                temp += `
                </select>
                </div>
                <div class="form-group">
                <label for="submenu" class="form-label">Submenu</label>
                <input type="text" id="submenu" name="submenu" class="form-control" value="`+data.submenu+`">
                </div>
                <div class="form-group">
  <label for="url" class="form-label">URL</label>
  <div class="input-group">
    <span class="input-group-text" id="basic-addon3">`+uri+`</span>
    <input type="text" class="form-control" id="url" name="url" value="`+data.url+`">
  </div>
</div>
                <div class="form-group">
                <label for="icon" class="form-label">Icon</label>
                <input type="text" id="icon" class="form-control input-icon-search" onkeyup="search_icon($(this))">
                <div class="mt-2 icon-body overflow-auto">
                <table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Icon</th>

            <th>Class</th>
        </tr>
    </thead>
    <tbody>
<tr>
            <td>
                <div class="form-check">
  <input class="form-check-input" type="radio" name="icon" id="icon" value="`+data.icon+`" checked>
</div>
            </td>
            <td><i class="fa-solid fa-fw `+data.icon+`"></i></td>
            <td>`+data.icon+`</td>
        </tr>
    </tbody>
    </table>
                </div>
                </div>`;
            $("#DataModal .modal-body").html(temp);
                });
                

                
                    
                    


                },false);

            
        break;
        case 'users':
            $("#DataModal .modal-title").html("Edit User");
            send_ajax(url,{get:"user_role"},function(role){
                const roles = role;
                getdatabyid("Vendor/getbyid",data,function(data){
                  
                     let temp = `
                    <div class="form-group">
                <input type="hidden" id="id" name="id" class="form-control" value="`+data.id+`">
                    <label for="role" class="form-label">Role</label>
                    <select class="form-control" name="role_id" id="role">
                    <option value="`+data.role_id+`" selected>Role : `+data.role+`</option>`;
                    for(var i = 0;i < roles.length;i++){
                     temp += `<option value="`+roles[i].id+`">`+roles[i].role+`</option>`;
                     
                    }
                temp += `
                </select>
                </div>
                <div class="form-group">
                <label for="email" class="form-label">Email</label>
                <input type="email" id="email" name="email" class="form-control" value="`+data.email+`">
                </div>
                <div class="form-group">
                <label for="name" class="form-label">Name</label>
                <input type="text" id="name" name="name" class="form-control" value="`+data.name+`">
                </div>
                <div class="form-group">
                <label for="phone" class="form-label">Phone</label>
                <input type="tel" id="phone" name="phone" class="form-control" value="`+data.phone+`">
                </div>

`;
            $("#DataModal .modal-body").html(temp);
                });
                

                
                    
                    


                },false);

            
        break;
        case 'reset_password':
            $("#DataModal .modal-title").html("Reset Password");
            getdatabyid("Vendor/getbyid",data,function(data){
            let temp = `
                <div class="form-group">
                <label for="email" class="form-label">Email</label>
               <input type="text" id="email" name="email" class="form-control" value="`+data.email+`" readonly> 
                </div>
                <div class="form-group">
                <label for="password" class="form-label">New Password</label>
                <input type="password" id="password" name="password" class="form-control">
                </div>
                
                <div class="form-group">
                <label for="repassword" class="form-label">Repeat Password</label>
                <input type="password" id="repassword" name="repassword" class="form-control">
                </div>`;
            $("#DataModal .modal-body").html(temp);
            $("#DataModal .modal-footer .trigger").html("Reset");
    $("#DataModal .modal-footer .trigger").attr("class","trigger btn btn-warning");
    $("#DataModal .modal-footer .trigger").attr("name","reset");
            });
        break;
        case 'merchantcogs':
            
           
            var email = btoa(data.attr("data-email"));
                var t = `
            <a href="`+uri+`Vendor/exitmerchant/`+email+`" class="btn btn-danger btn-user btn-block">Exit Merchants</a>
            `;
            
            
            $('#DataModal .modal-footer').css("display","none");
            $('#DataModal .modal-body').html(t);
            $("#DataModal .modal-title").html("Merchant Settings");
        break;
    }
}
function deleteDataModal(data){
    const url = $("body").attr("data-url")+"Vendor/get_data";
    $("#DataModal .modal-footer .trigger").html("Delete");
    $("#DataModal .modal-footer .trigger").attr("class","trigger btn btn-danger");
    $("#DataModal .modal-footer .trigger").attr("name","delete");
    switch (data.attr("data-temp")) {
        case 'menu':
        $("#DataModal .modal-title").html("Delete Menu");
                
        getdatabyid("Vendor/getbyid",data,function(data){
               let temp = `<input type="hidden" name="id" value="`+data.id+`"><p>Do you want to delete <span class="text-danger">`+data.menu+` menu</span>?</p>`;
            $("#DataModal .modal-body").html(temp);
        });
        break;
        case 'role':
        const idd = data.attr("data-id");
        $("#DataModal .modal-title").html("Delete Role");
        send_ajax(url,{get:"user_role"},function(role){
            const roles = role;
            
            getdatabyid("Vendor/getbyid",data,function(data){
                    let temp = `<input type="hidden" name="id" value="`+data.id+`"><p>Do you want to delete <span class="text-danger">`+data.role+` role</span>?</p>`;
                     temp += `
                    <div class="form-group">

                    <select class="form-control" name="role_id">
                    <option value="0" selected>Point the user to another role</option>`;
                    for(var i = 0;i < roles.length;i++){
                        if (roles[i].id != idd) {
                            
                        
                     temp += `<option value="`+roles[i].id+`">`+roles[i].role+`</option>`;
                        }
                    }
        

            $("#DataModal .modal-body").html(temp);
            });
        },false);
        break;
        case 'submenu':
        $("#DataModal .modal-title").html("Delete Submenu");
                
        getdatabyid("Vendor/getbyid",data,function(data){
               let temp = `<input type="hidden" name="id" value="`+data.id+`"><p>Do you want to delete <span class="text-danger">`+data.submenu+` submenu</span>?</p>`;
            $("#DataModal .modal-body").html(temp);
        });
        case 'billing':
        $("#DataModal .modal-title").html("Delete Billing");
                
        getdatabyid("Vendor/getbyid",data,function(data){
            
               let temp = `<input type="hidden" name="billing_id" value="`+data.b_id+`"><input type="hidden" name="merchant" value="`+data.merchant+`"><p>Do you want to delete <span class="text-danger">`+data.billing+`</span>?</p>`;
            $("#DataModal .modal-body").html(temp);
        });
        break;
        case 'usermerchant':
        $("#DataModal .modal-title").html("Delete User From Merchant");
                
        getdatabyid("Vendor/getbyid",data,function(data){
            
               let temp = `<input type="hidden" name="email" value="`+data.email+`"><p>Do you want to delete user <span class="text-danger">`+data.email+`</span> from your merchant?</p>`;
            $("#DataModal .modal-body").html(temp);
        });
        break;
        case 'users':
        $("#DataModal .modal-title").html("Delete User");
                
        getdatabyid("Vendor/getbyid",data,function(data){
               let temp = `<input type="hidden" name="id" value="`+data.id+`"><p>Do you want to delete user <span class="text-danger">`+data.email+`</span>?</p>`;
            $("#DataModal .modal-body").html(temp);
        });
        break;
        case 'notif':
        $("#DataModal .modal-title").html("Delete Notif");
                
        getdatabyid("Vendor/getbyid",data,function(data){
               let temp = `<input type="hidden" name="id" value="`+data.id+`"><a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle" style="background-color: `+data.color+`">
                                            <i class="fa-solid text-white `+data.icon+`"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">For : `+data.notif_for+`</div>
                                        <span class="font-weight-bold">`+data.content+`</span>
                                    </div>
                                </a>`;
            $("#DataModal .modal-body").html(temp);
            
        });
        break;
    }
}
function getdatabyid(u,d,a){
    let url = $("body").attr("data-url")+u;
    let name = d.attr("data-temp");
    let id = d.attr("data-id");
    
    $.ajax({
        url:url,
        data:{name:name,id:id},
        method: 'post',
        dataType: 'json',
        success: a
    });
}
function send_ajax(url,data,a,type = true){
    
    if (type) {
        $.ajax({
        url:url,
        data:data,
        method: 'post',
        success: a
    });
    } else {
        $.ajax({
        url:url,
        data:data,
        dataType: 'json',
        method: 'post',
        success: a
    });
    }
    

}
function search_icon(data){
    const url = $("body").attr("data-url")+"Vendor/icon";
    const keyword = data.val();
    send_ajax(url,{keyword:keyword},function(page){
        $(".icon-body").html(page);
    });
}
function change_access(data){
    let url = $("body").attr("data-url");
    const uri = url;
    const r = data.attr("r-id");
    const m = data.attr("m-id");
    send_ajax(url+"Vendor/change_access",{menu_id:m,role_id:r},function(){
        window.location.href = uri+'Admin/Access/'+encodeURI(btoa(r));
    });
}
function change_submenu_active(data){
    let url = $("body").attr("data-url");
    const uri = url;
    const id = data.attr("data-id");
    const ac = data.attr("data-active");
    send_ajax(url+"Vendor/change_submenu_active",{is_active:ac,id:id},function(){
        window.location.href = uri+'Menu/ManageSubmenu';
    });
}

function change_user_active(data){
    let url = $("body").attr("data-url");
    const uri = url;
    const id = data.attr("data-id");
    const ac = data.attr("data-active");
    send_ajax(url+"Vendor/change_user_active",{is_active:ac,id:id},function(){
        window.location.href = uri+'Admin/Users';
    });
}
function role_default(data){
    let url = $("body").attr("data-url");
    const uri = url;
    const id = data.attr("data-id");
    const rd = data.attr("data-rd");
    send_ajax(url+"Vendor/role_default",{role_default:rd,id:id},function(){
        
        window.location.href = uri+'Admin/Role';
    });
}
function otp(data){
    let url = $("body").attr("data-url");
    let email = data.attr("data-email");
    let m_id = $("#m-id").val()
    let otp = makeotp(6);
   let ot = {email:email,otp:otp,m_id:m_id};
    
    send_ajax(url+"Vendor/send_otp",ot,function(ott){
        
        $('#DataModal .modal-footer').css("display","none");
        $("#DataModal .modal-title").html("OTP");
        if (ott.result == false) {
            $("#DataModal .modal-body").html("OTP failed to sent");
        $('#DataModal').modal('show');
        }else{
            $("#DataModal .modal-body").html("OTP is sent to the merchant owner's email");
            var mail = {
                to: ott.primary,
                subject: "Merchant Authorization",
                header: `<h1 style="font-size: 14px;">Merchant Authorization</h1>`+ott.primary,
                success : $('#DataModal').modal('show'),
                body: `<p class="text-left" style="text-align:left;">`+ott.email+` wants to join your merchant please provide the following otp to continue.</p>
          <div class="btn btn-primary" style="display: inline-block;
  padding: 6px;
  color: #ffffff;
  text-align: center;
  border: 1px double #cccccc;
  border-radius: 5px;
  font-size: 10px;
  cursor: pointer; /* add this line */
  text-decoration: none;
  background-color: #0d6efd;">`+ott.otp+`</div>`
            }
            send_mail(mail);
        }
        

        
    },false);
}
function makeotp(n) {
    let randomtextnumber;
    for (var r = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", 
"o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F",
 "G", "H", "I",  "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W",
 "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
 e = n, t = new Array, a = 0; a <= e - 1; a++) {
        t[a] = r[parseInt(Math.random() * r.length)];
        t = t;
        randomtextnumber = t.join("");
    }
    return randomtextnumber;
}
function send_mail(v){
    var Email = { send: function (a) { return new Promise(function (n, e) { a.nocache = Math.floor(1e6 * Math.random() + 1), a.Action = "Send"; var t = JSON.stringify(a); Email.ajaxPost("https://smtpjs.com/v3/smtpjs.aspx?", t, function (e) { n(e) }) }) }, ajaxPost: function (e, n, t) { var a = Email.createCORSRequest("POST", e); a.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), a.onload = function () { var e = a.responseText; null != t && t(e) }, a.send(n) }, ajax: function (e, n) { var t = Email.createCORSRequest("GET", e); t.onload = function () { var e = t.responseText; null != n && n(e) }, t.send() }, createCORSRequest: function (e, n) { var t = new XMLHttpRequest; return "withCredentials" in t ? t.open(e, n, !0) : "undefined" != typeof XDomainRequest ? (t = new XDomainRequest).open(e, n) : t = null, t } };
    var card = `<div class="card" style="width: 90%;
 margin: 20px auto;
 background-color: #F8FBFE;
 border-radius: 8px;
 z-index: 1;
 font-size: 10px;
 text-align: center;
 padding: 10px 10px;
 border: 1px solid #eaeaea;">
  <header style="margin-bottom: 1rem;">
    `+v.header+`
  </header>
  <hr>
  <div class="card__content" style="margin-bottom: 1rem;">
`+v.body+`
  </div>
  <hr>
  <footer>
      <span>Copyright &copy; Arspay 2023</span>
  </footer>
</div>`;
Email.send({
    SecureToken : config.mail.SecureToken,
    Host : config.mail.Host,
    Username : config.mail.Username,
    Password : config.mail.Password,
    To : v.to,
    From : config.mail.Username,
    Subject : v.subject,
    Body : card
}).then(function(message){
    v.success;
});
}
function snap(){
    
}