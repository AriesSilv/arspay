$(".costum-file-input").change(function(){
    let filename = $(this).val().split('\\').pop();
    
    $(this).next(".costum-file-label").addClass("selected").html(filename);
});
    $(".data-modal").click(function(){
    if($(this).attr("data-action") == "add"){
        
        addDataModal($(this));
    }else if($(this).attr("data-action") == "edit"){
        editDataModal($(this));
    }else if($(this).attr("data-action") == "delete"){
        deleteDataModal($(this));
    }
    });
$(".check_access").click(function(){
    change_access($(this));
});
$(".submenu_active").click(function(){
    change_submenu_active($(this));
});
$(".users_active").click(function(){
    
    change_user_active($(this));
});
$(".role_default").click(function(){
    role_default($(this));
});

$(".send_otp").click(function(){
    otp($(this));
});






